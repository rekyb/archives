---
name: loop-manual
description: A playbook of 10 repeatable prompt-loop-context engineering patterns for working with Claude and Claude Code. Use this skill whenever the user wants to learn or understand a topic (especially "where do I start", "teach me", "go deeper", "quiz me", "explain X"), design or improve a workflow or process, or run a structured engineering loop with Claude Code (planning a feature, TDD, code review, CLAUDE.md setup, subagents, verification). Also trigger when the user says "loop manual", "which loop", "run loop N", or asks how to get better results from Claude for frontend, backend, database, data engineering, or design system work.
---

# The Loop Manual

10 repeatable patterns. Every pattern is a loop with agent steps, human gates, and an explicit exit condition — never a one-shot prompt.

## How to use this skill

1. Identify the user's situation in the routing table below.
2. Read the matching reference file for the full loop (steps, prompts, pitfalls).
3. **Run the loop with the user** — don't just describe it. Start step 1 immediately, enforce the human gates (stop and wait for the user's decision), and hold the exit condition strictly.
4. If the user names a loop ("run loop 03", "Feynman me on X"), skip routing and start it.

## Routing table

| Situation | Loop | Reference file |
|---|---|---|
| Doesn't understand a topic, no idea where to start | 01 Terrain Mapping | references/learning-loops.md |
| Wants to dive deeper on a topic they partly know | 02 Depth Ladder | references/learning-loops.md |
| Wants knowledge to stick / retention / studying | 03 Feynman Teach-Back | references/learning-loops.md |
| Wants the optimum workflow for any process | 04 Workflow Interview | references/learning-loops.md |
| Any non-trivial coding task | 05 Explore→Plan→Code→Commit | references/coding-loops.md |
| Logic with a verifiable contract (backend, transforms) | 06 Test-First (TDD) | references/coding-loops.md |
| Repeated corrections, CLAUDE.md, rules, skills setup | 07 Context Engineering | references/coding-loops.md |
| Big research task, or reviewing work independently | 08 Subagent Fan-Out + Fresh Eyes | references/coding-loops.md |
| Multi-session work that must survive /clear | 09 Spec-as-File | references/coding-loops.md |
| Claude (or anyone) claims "done" / "fixed" / "works" | 10 Evidence & Adversarial Verify | references/coding-loops.md |
| Frontend / backend / database / data eng / design system task | Domain combo | references/domain-playbooks.md |

## Three laws (apply to every loop)

1. **Context is the budget.** Spend it on signal: clear between tasks, fan noisy research out, keep persistent instructions lean.
2. **Loops beat one-shots.** Design the feedback step before writing the prompt.
3. **Evidence, not claims.** A loop ends with proof (test output, a passed quiz, a command result) or it hasn't ended.

## Behavioral rules when running any loop

- Announce which loop is running and its exit condition in one line, then start. No meta-lecture about the manual.
- Human gates are hard stops: present the decision, then wait. Never auto-approve on the user's behalf.
- Grade strictly in learning loops (02, 03) — vague answers count as wrong.
- In review loops (08, 10) flag only correctness gaps, not style preferences.
- One loop at a time unless the user asks to combine them.
