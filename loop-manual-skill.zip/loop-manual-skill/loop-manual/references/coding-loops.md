# Coding Loops (05–10)

These loops target Claude Code sessions, but the shapes apply in any Claude surface. "Gate" = hard stop, wait for the user.

---

## 05 · Explore → Plan → Code → Commit

**WHEN:** Any non-trivial coding change. The default loop for real work.

**SHAPE:** EXPLORE (read only) → PLAN (plan mode) → [GATE: user approves plan] → CODE one step → VERIFY + COMMIT → /clear → next task.

**HOW TO RUN:**
1. Explore first: read the relevant files, summarize current flow, files involved, anything surprising. Zero code changes in this phase.
2. Plan in plan mode (Shift+Tab in Claude Code): files to touch, risks, edge cases, verification per step.
3. Gate: user reads the plan like a PR and cuts scope creep. Cheapest place to fix mistakes.
4. Implement one plan step at a time; show the diff and test output before the next step.
5. Commit with a message naming the plan step. /clear before unrelated work.

**EXIT:** Per task. The loop restarts for each task with fresh context.

**PITFALL:** Jumping straight to "build me X" for anything bigger than a one-liner — saves 2 minutes of planning, costs 40 reviewing code that solved the wrong problem.

---

## 06 · Test-First Loop (TDD)

**WHEN:** Backend logic, data transforms, anything with a verifiable contract.

**SHAPE:** WRITE failing tests → RUN, confirm red → [GATE: user commits/freezes tests] → IMPLEMENT until green → fresh-eyes check (Loop 08).

**HOW TO RUN:**
1. Derive tests from behavior (input/output pairs + edge cases: empty, null, oversized, concurrent), not from code. No implementation, no stubs.
2. Run the tests and show they fail. A test that passes before the code exists tests nothing.
3. Gate: user commits the tests. From here the tests are the spec; do not modify them.
4. Implement iteratively: code → run → read failures → fix, until all green. Never edit a test to make it pass — if a test seems wrong, stop and raise it as an explicit human decision.
5. Fresh-eyes subagent checks for overfitting (hard-coded answers, missed generalization).

**EXIT:** All green AND reviewer reports no correctness gaps versus the spec.

**PITFALL:** "Fixing" a failing test instead of the code. The freeze-commit exists exactly for this.

---

## 07 · Context Engineering Loop

**WHEN:** Always. The maintenance loop that makes every other loop cheaper.

**SHAPE:** NOTICE repeated correction → [GATE: user promotes it to the right layer] → PRUNE stale rules → repeat weekly, forever.

**LAYERS (cheapest that works wins):**
1. **CLAUDE.md** (always loaded): commands, conventions, non-obvious gotchas. Keep lean — bloat taxes every message. Rule of thumb: corrected twice → add it; stopped firing → delete it.
2. **Rules files** (path-scoped): `.claude/rules/*.md` with path globs — load only when matching files are touched.
3. **Skills** (loaded on trigger): folders with SKILL.md for repeated workflows. Short trigger description, heavy detail in body/references. Maintain a Gotchas section; append every caught failure.
4. **Session hygiene:** /clear between unrelated tasks; noisy research → subagents; long session dragging → write a handoff summary to a file, restart from it.

**Bootstrap prompt for a bare repo:** analyze the repo and draft a CLAUDE.md under 60 lines — build/test/lint commands, architecture in 5 bullets, inferable conventions, gotchas — marking uncertain items with (?) for the user to confirm.

**Weekly prune prompt:** "Read CLAUDE.md and our rules/skills. Flag anything stale, contradictory, or recently ignored."

**PITFALL:** Escalating to ALL CAPS instead of pruning. If an instruction is ignored, the file is too long or the rule belongs in harness-enforced settings (permissions, hooks), not prose.

---

## 08 · Subagent Fan-Out + Fresh Eyes

**WHEN:** Research across many files, or reviewing work without self-grading bias.

**SHAPE:** FAN OUT parallel subagents → MERGE conclusions only → FRESH-EYES review vs spec → [GATE: user triages findings] → fix → re-review.

**HOW TO RUN:**
1. Fan out for breadth: independent questions to parallel subagents (e.g., how auth works / how errors are logged / test coverage). Subagents report conclusions only — raw file dumps stay out of the main context.
2. Stay inline for depth: hard reasoning the user should watch belongs in the main session. Fork for scanning, not thinking.
3. After implementation, a fresh-context reviewer checks the diff against the plan/spec: every requirement implemented, listed edge cases tested, nothing outside scope changed.
4. Constrain the reviewer: flag only gaps affecting correctness or stated requirements. An unconstrained reviewer always finds something — that's over-engineering fuel.
5. Gate: user triages. Correctness gaps mandatory; everything else optional by default.

**EXIT:** Reviewer reports no correctness gaps.

**PITFALL:** Chasing every finding. A reviewer asked to find gaps finds gaps even in sound work.

---

## 09 · Spec-as-File Loop

**WHEN:** Multi-hour or multi-session work; anything that must survive /clear.

**SHAPE:** WRITE PLAN.md with checkboxes → [GATE: user edits the file directly] → EXECUTE one checkbox → TICK + log evidence → repeat.

**HOW TO RUN:**
1. Write PLAN.md: `## Goal` (2 lines) · `## Non-goals` · `## Steps` as checkboxes, each small enough to verify independently, each with a `verify:` line stating the exact command or check.
2. Stop. The user edits the file before execution — deleting a step in the file is a stronger signal than chat.
3. Execute one checkbox at a time. After each: tick it and append one line of evidence under it.
4. Context dies? Irrelevant. New session: "Read PLAN.md, continue from the first unticked box." The file is the memory.
5. Scale: multiple plan files + git worktrees = parallel sessions on independent tasks without collisions.

**EXIT:** Every box ticked. The file is now the changelog.

**PITFALL:** Steps too big to verify. "Build the API" is not a step; "POST /sessions returns 201 with a valid token (verify: curl + test run)" is.

---

## 10 · Evidence & Adversarial Verify Loop

**WHEN:** Before trusting any "done", "fixed", or "it works now" — from Claude or anyone.

**SHAPE:** CLAIM → SHOW evidence → SECOND AGENT tries to refute → [GATE: user accepts or bounces] → repeat.

**HOW TO RUN:**
1. Standing rule (belongs in CLAUDE.md): never claim success without the exact command run and its full output; screenshots for UI changes. No evidence, no claim.
2. Reviewing evidence beats re-running it — and it's the only way to trust unattended sessions.
3. Adversarial pass: a fresh-context agent is told to REFUTE, not confirm — "Assume this fix is wrong. Find the input, sequence, or state that breaks it. Write the failing test if found. If you can't break it, say exactly what you tried."
4. Refuter finds something → back to the implementer with the counterexample. Nothing → user accepts.
5. Automate the floor: hooks running lint/tests after edits; CI as the final refuter. Machines enforce what prose merely requests.

**EXIT:** The refuter fails to break it.

**PITFALL:** Asking "does this work?" of the context that wrote it — it will say yes. Verification must come from a different context than creation, or from a machine.
