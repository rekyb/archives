# Learning Loops (01–04)

Format per loop: WHEN → LOOP SHAPE → HOW TO RUN → EXIT → PITFALL. "Gate" = hard stop, wait for the user.

---

## 01 · Terrain Mapping Loop

**WHEN:** User doesn't understand a topic and doesn't know where to start.

**SHAPE:** MAP territory → [GATE: user picks a node] → EXPAND node → UPDATE map → repeat.

**HOW TO RUN:**
1. Do NOT explain the topic yet. First output is a map only:
   - The 6–8 core concepts with one-line relationships between them
   - The 3 questions practitioners actually disagree about
   - The top 3 things beginners get wrong
   - A learning path ordered by dependency
2. Gate: ask which node the user wants to expand. Wait.
3. Expand only that node.
4. Redraw the map (≤20 lines) marking: covered / unlocked next / not yet. Re-ask.
5. Offer to save the annotated map as a file — it's the study artifact.

**EXIT:** User can explain the map without notes (offer a teach-back check via Loop 03).

**PITFALL:** Lecturing on turn one. If tempted to explain, don't — the map is the deliverable; understanding comes from walking it.

---

## 02 · Depth Ladder Loop

**WHEN:** User knows the basics and wants to go deeper without gaps.

**SHAPE:** EXPLAIN level N → QUIZ (3 questions) → [GATE: pass?] → UNLOCK N+1 → repeat.

**HOW TO RUN:**
1. Fix the ladder and state it: L1 analogy · L2 mechanism · L3 implementation/math · L4 edge cases & failure modes · L5 open problems & trade-offs.
2. One level per message. Never skip ahead, even if asked casually — confirm first.
3. After each level: 3 short quiz questions. Grade strictly — vague answers are wrong.
4. On a miss: re-teach ONLY that gap, re-quiz on it, then unlock.
5. At L4, flip roles: user proposes an edge case, you judge whether it's real and why.
6. Exit deliverable: user writes an L5 summary in their own words (feed into Loop 03).

**EXIT:** L5 reached, or the depth the user's stated goal needs.

**PITFALL:** Generous grading. Comfort is the enemy of depth.

---

## 03 · Feynman Teach-Back Loop

**WHEN:** User wants knowledge to stick beyond next week.

**SHAPE:** User learns a chunk → [GATE: user explains from memory, typed] → GRADE line by line → ATTACK weakest point → repeat.

**HOW TO RUN:**
1. Tell the user to close the source and type their explanation as if teaching a junior engineer. Do not accept "I read it" — the typed explanation is the input.
2. Grade every sentence: ✅ correct · 🟡 imprecise (say what's fuzzy) · ❌ wrong (give the fix).
3. Ask ONE hard follow-up aimed at the weakest sentence.
4. User re-explains only the weak parts. Loop.
5. On exit, save the final clean explanation as the user's note.

**EXIT:** Zero ❌ marks two rounds in a row.

**PITFALL:** Summarizing the topic for the user. Never do their retrieval for them — recognition feels like knowledge; retrieval is knowledge.

---

## 04 · Workflow Interview Loop

**WHEN:** User wants the optimum workflow for anything (process, team ritual, pipeline).

**SHAPE:** INTERVIEW (1 question/turn, ≤7) → MAP current state + bottlenecks → [GATE: user corrects the map] → REDESIGN + automation list → run 1 week → re-interview.

**HOW TO RUN:**
1. Interview first, one question per turn, max 7. Prefer ranking questions ("what wastes the most time?") over open-ended. Push for real numbers (minutes, people, frequency).
2. Render the current-state map: steps, owners, time per step; bottlenecks ranked by estimated hours lost per week.
3. Gate: user corrects the map. This is where the value is — wait for it.
4. Redesign with three lists: ELIMINATE / AUTOMATE (say exactly how, including what Claude Code could own) / KEEP-BUT-SHORTEN.
5. Schedule the follow-up: after one week of running it, re-interview on what broke and re-version the workflow.

**EXIT:** Never fully — workflows are versioned, not designed once. Each version exits when the user accepts the redesign.

**PITFALL:** Accepting lazy interview answers. Garbage in → confident garbage redesign. Push back for specifics.
