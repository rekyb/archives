# Domain Playbooks

Each discipline = a combo of core loops + one domain twist. Apply the loops from the other reference files, adjusted as below.

---

## Frontend Engineering
**Combo:** 05 EPCC + visual iteration ×2–3 + 07 (design tokens as a rules file or skill)

**Twist:** Claude can't see its output unless shown. Loop: screenshot → paste → "compare against the mock, list every visual difference (spacing, type, color, alignment), fix them" → re-screenshot. Converges in 2–3 rounds. Design tokens (colors, type, spacing) live in a rules file or house-style skill so every component starts on-brand instead of on Claude's defaults.

## Backend Engineering
**Combo:** 06 TDD + 09 spec-as-file + 10 evidence — contract-first

**Twist:** Define the API contract (OpenAPI / types / example payloads, including error responses and auth) before any handler exists. Gate on the contract. Tests derive from the contract: happy path + every error code + at least one concurrency case — error paths and concurrency are where agents under-test by default. Refuter (Loop 10) attacks exactly those.

## Database Engineering
**Combo:** 09 spec-as-file + 10 evidence, with a hard destructive-action gate

**Twist:** Everything reversible or it doesn't run. Migrations ship as up/down pairs, tested against a copy. Standing rule: never execute destructive SQL — print it and stop for the user. Performance claims require EXPLAIN ANALYZE before/after on realistic row counts, never the dev seed table.

## Data Engineering
**Combo:** 08 fan-out (pipeline audit) + 06 tests-on-data + 10 evidence (reconciliation counts)

**Twist:** Correctness is statistical. Fan out subagents to map source → transform → sink, find silent row drops/duplication, inventory existing checks. Every transform ships with assertions: expected row-count delta, null-rate bounds, uniqueness keys, referential integrity. "The pipeline works" means reconciliation numbers source-vs-sink, not green logs.

## Design Engineering / Design Systems
**Combo:** 01 terrain map (audit) + 04 workflow interview + 07 (tokens in git, house-style skill)

**Twist:** A design system is context engineering applied to visuals. Tokens live in git as single source of truth; a house-style skill makes generated screens start from those tokens; a fresh-eyes agent (08) audits new components for hardcoded values bypassing tokens and patterns that should have reused existing components — fix list ranked by user-visible impact.
