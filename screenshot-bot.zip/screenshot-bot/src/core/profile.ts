import { homedir } from "node:os";
import { join } from "node:path";

/** Default Chrome user-data directory for the current OS. */
export function defaultChromeUserDataDir(platform: NodeJS.Platform = process.platform): string {
  const home = homedir();
  switch (platform) {
    case "darwin":
      return join(home, "Library", "Application Support", "Google", "Chrome");
    case "win32":
      return join(
        process.env.LOCALAPPDATA ?? join(home, "AppData", "Local"),
        "Google",
        "Chrome",
        "User Data",
      );
    default:
      return join(home, ".config", "google-chrome");
  }
}

/**
 * Resolve which Chrome profile dir to use, in order:
 * explicit arg → SCREENSHOT_BOT_BROWSER_PROFILE → OS default.
 */
export function resolveProfileDir(explicit?: string): string {
  if (explicit && explicit.length > 0) return explicit;
  const env = process.env.SCREENSHOT_BOT_BROWSER_PROFILE;
  if (env && env.length > 0) return env;
  return defaultChromeUserDataDir();
}
