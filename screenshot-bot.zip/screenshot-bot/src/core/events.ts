import type { Step } from "./recipe";

export interface RunSummary {
  sites: number;
  totalSteps: number;
  totalFailed: number;
}

/**
 * Events emitted by the runner as an async stream. The headless CLI prints
 * them; the Ink TUI renders them live. One crawl implementation, two consumers.
 */
export type RunEvent =
  | { type: "runStart"; runId: string; sites: string[] }
  | { type: "siteStart"; site: string; outDir: string; stepCount: number }
  | { type: "stepStart"; site: string; index: number; label: string }
  | {
      type: "stepDone";
      site: string;
      index: number;
      label: string;
      durationMs: number;
      screenshot?: string;
    }
  | {
      type: "stepFailed";
      site: string;
      index: number;
      label: string;
      error: string;
      screenshot?: string;
    }
  | { type: "siteEnd"; site: string; ok: number; failed: number }
  | { type: "runEnd"; summary: RunSummary };

/** A short human-readable description of a step, used in labels and logs. */
export function describeStep(step: Step): string {
  switch (step.type) {
    case "goto":
      return `goto ${step.url}`;
    case "click":
      return `click ${step.selector}`;
    case "fill":
      return `fill ${step.selector} = ${JSON.stringify(step.value)}`;
    case "waitFor":
      return `waitFor ${step.target}`;
    case "scroll":
      return `scroll ${step.target}`;
    case "screenshot":
      return `screenshot ${step.name}`;
    case "press":
      return `press ${step.key}`;
    case "select":
      return `select ${step.selector} = ${JSON.stringify(step.value)}`;
  }
}
