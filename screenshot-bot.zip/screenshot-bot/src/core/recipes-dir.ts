import { readdir, readFile } from "node:fs/promises";
import { basename, join } from "node:path";
import { loadRecipe, type Recipe } from "./recipe";

/** List recipe names (file stems) in a recipes directory. */
export async function listRecipeNames(dir: string): Promise<string[]> {
  let entries: string[] = [];
  try {
    entries = await readdir(dir);
  } catch {
    return [];
  }
  return entries
    .filter((f) => f.endsWith(".yaml") || f.endsWith(".yml"))
    .map((f) => basename(f, f.endsWith(".yaml") ? ".yaml" : ".yml"))
    .sort();
}

/** Load a single recipe by name from a recipes directory. */
export async function loadRecipeByName(dir: string, name: string): Promise<Recipe> {
  for (const ext of [".yaml", ".yml"]) {
    try {
      const text = await readFile(join(dir, `${name}${ext}`), "utf8");
      return loadRecipe(text);
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code === "ENOENT") continue;
      throw new Error(`Failed to load recipe "${name}": ${(err as Error).message}`);
    }
  }
  throw new Error(`Recipe "${name}" not found in ${dir}`);
}

/** Load recipes by name, or all recipes in the directory when names is empty. */
export async function loadRecipes(dir: string, names: string[]): Promise<Recipe[]> {
  const wanted = names.length > 0 ? names : await listRecipeNames(dir);
  return Promise.all(wanted.map((n) => loadRecipeByName(dir, n)));
}
