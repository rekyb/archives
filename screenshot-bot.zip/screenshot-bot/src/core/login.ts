import { createInterface } from "node:readline/promises";
import { launchBrowser, newContext } from "./browser";
import { saveSession } from "./session";
import type { Recipe } from "./recipe";

/**
 * Open a headed Chrome at the recipe's baseUrl so the user can log in by hand
 * (including Google), then save the session for reuse. Manual headed login is
 * what lets Google sign-in succeed — it sees a real human in a real browser.
 */
export async function loginFlow(
  recipe: Recipe,
  sessionsDir: string,
  opts: { waitForEnter?: () => Promise<void> } = {},
): Promise<string> {
  const sessionName = recipe.session ?? recipe.name;
  const browser = await launchBrowser(false);
  try {
    const { context, page } = await newContext(browser, { viewport: recipe.viewport });
    await page.goto(recipe.baseUrl, { waitUntil: "load" });

    const wait =
      opts.waitForEnter ??
      (async () => {
        const rl = createInterface({ input: process.stdin, output: process.stdout });
        await rl.question(
          `\nLog in manually in the opened Chrome window (including Google).\n` +
            `When you're done and see the logged-in page, press Enter here… `,
        );
        rl.close();
      });
    await wait();

    return await saveSession(context, sessionsDir, sessionName);
  } finally {
    await browser.close();
  }
}
