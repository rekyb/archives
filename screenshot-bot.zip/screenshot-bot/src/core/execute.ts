import { join } from "node:path";
import { createLogger } from "./logger";
import { runRecipes } from "./runner";
import type { RunEvent } from "./events";
import type { Recipe } from "./recipe";

export interface ExecuteOptions {
  runId: string;
  outputRoot: string;
  sessionsDir: string;
  headless?: boolean;
  timeoutMs?: number;
  /** Use the real Chrome profile at this dir (already logged in). */
  profileDir?: string;
  /** Live consumer (e.g. the TUI) invoked for every event, after it's logged. */
  onEvent?: (event: RunEvent) => void;
}

/**
 * Run recipes, writing run.jsonl + run.log under output/<runId>/ and forwarding
 * each event to an optional live consumer. Shared by the CLI and the TUI.
 */
export async function executeRun(recipes: Recipe[], opts: ExecuteOptions): Promise<void> {
  const logDir = join(opts.outputRoot, opts.runId);
  const logger = await createLogger(logDir);
  try {
    for await (const event of runRecipes(recipes, {
      runId: opts.runId,
      outputRoot: opts.outputRoot,
      sessionsDir: opts.sessionsDir,
      ...(opts.headless !== undefined ? { headless: opts.headless } : {}),
      ...(opts.timeoutMs !== undefined ? { timeoutMs: opts.timeoutMs } : {}),
      ...(opts.profileDir ? { profileDir: opts.profileDir } : {}),
    })) {
      await logger.log(event);
      opts.onEvent?.(event);
    }
  } finally {
    await logger.close();
  }
}
