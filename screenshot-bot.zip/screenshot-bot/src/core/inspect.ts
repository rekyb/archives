import { createInterface } from "node:readline/promises";
import { launchBrowser, newContext } from "./browser";
import { storageStateFor } from "./session";
import type { Recipe } from "./recipe";

/**
 * Open a headed Chrome at a URL with the recipe's saved session applied, so a
 * human (or Claude, via the browser tools) can examine the page and pick robust
 * selectors while authoring or repairing a recipe. Stays open until Enter.
 */
export async function inspectFlow(
  recipe: Recipe,
  sessionsDir: string,
  target?: string,
): Promise<void> {
  const storageStatePath = recipe.session
    ? await storageStateFor(sessionsDir, recipe.session)
    : undefined;
  const browser = await launchBrowser(false);
  try {
    const { page } = await newContext(browser, {
      viewport: recipe.viewport,
      ...(storageStatePath ? { storageStatePath } : {}),
    });
    const url = target ? new URL(target, recipe.baseUrl).toString() : recipe.baseUrl;
    await page.goto(url, { waitUntil: "load" });

    const rl = createInterface({ input: process.stdin, output: process.stdout });
    await rl.question(`\nInspecting ${url}. Press Enter to close… `);
    rl.close();
  } finally {
    await browser.close();
  }
}
