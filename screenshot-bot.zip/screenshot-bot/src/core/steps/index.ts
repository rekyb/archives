import { join } from "node:path";
import type { Page } from "playwright";
import type { Step } from "../recipe";

export interface StepContext {
  baseUrl: string;
  outDir: string;
}

export interface StepResult {
  screenshot?: string;
}

async function waitFor(page: Page, target: string): Promise<void> {
  if (target === "networkidle") {
    await page.waitForLoadState("networkidle");
    return;
  }
  if (/^\d+$/.test(target)) {
    await page.waitForTimeout(Number(target));
    return;
  }
  await page.locator(target).first().waitFor({ state: "visible" });
}

async function scroll(page: Page, target: string): Promise<void> {
  if (target === "top") {
    await page.evaluate(() => window.scrollTo(0, 0));
    return;
  }
  if (target === "bottom") {
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    return;
  }
  await page.locator(target).first().scrollIntoViewIfNeeded();
}

/** Execute one recipe step against the page. Throws on failure (runner handles it). */
export async function executeStep(
  page: Page,
  step: Step,
  ctx: StepContext,
): Promise<StepResult> {
  switch (step.type) {
    case "goto":
      await page.goto(new URL(step.url, ctx.baseUrl).toString(), { waitUntil: "load" });
      return {};
    case "click":
      await page.locator(step.selector).first().click();
      return {};
    case "fill":
      await page.locator(step.selector).first().fill(step.value);
      return {};
    case "select":
      await page.locator(step.selector).first().selectOption(step.value);
      return {};
    case "press":
      await page.keyboard.press(step.key);
      return {};
    case "waitFor":
      await waitFor(page, step.target);
      return {};
    case "scroll":
      await scroll(page, step.target);
      return {};
    case "screenshot": {
      const file = `${step.name}.png`;
      await page.screenshot({ path: join(ctx.outDir, file), fullPage: true });
      return { screenshot: file };
    }
  }
}
