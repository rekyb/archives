import { createWriteStream, type WriteStream } from "node:fs";
import { mkdir } from "node:fs/promises";
import { join } from "node:path";
import { once } from "node:events";
import type { RunEvent } from "./events";

export interface Logger {
  log(event: RunEvent): Promise<void>;
  close(): Promise<void>;
}

function humanLine(at: string, e: RunEvent): string | undefined {
  const ts = at.slice(11, 19); // HH:MM:SS
  switch (e.type) {
    case "runStart":
      return `[${ts}] === run ${e.runId} :: ${e.sites.join(", ")} ===`;
    case "siteStart":
      return `[${ts}] --- ${e.site} (${e.stepCount} steps) → ${e.outDir}`;
    case "stepStart":
      return undefined; // stepDone/stepFailed carry the outcome
    case "stepDone":
      return `[${ts}]   ok   ${e.label} (${e.durationMs}ms)${e.screenshot ? ` → ${e.screenshot}` : ""}`;
    case "stepFailed":
      return `[${ts}]   FAIL ${e.label}: ${e.error}${e.screenshot ? ` → ${e.screenshot}` : ""}`;
    case "siteEnd":
      return `[${ts}] --- ${e.site} done (ok ${e.ok}, failed ${e.failed})`;
    case "runEnd":
      return `[${ts}] === run complete: ${e.summary.sites} site(s), ${e.summary.totalSteps} step(s), ${e.summary.totalFailed} failed ===`;
  }
}

export async function createLogger(dir: string): Promise<Logger> {
  await mkdir(dir, { recursive: true });
  const jsonl: WriteStream = createWriteStream(join(dir, "run.jsonl"), { flags: "a" });
  const human: WriteStream = createWriteStream(join(dir, "run.log"), { flags: "a" });

  return {
    async log(event) {
      const at = new Date().toISOString();
      jsonl.write(JSON.stringify({ at, ...event }) + "\n");
      const line = humanLine(at, event);
      if (line) human.write(line + "\n");
    },
    async close() {
      jsonl.end();
      human.end();
      await Promise.all([once(jsonl, "finish"), once(human, "finish")]);
    },
  };
}
