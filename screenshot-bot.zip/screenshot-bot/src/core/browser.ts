import { chromium, type Browser, type BrowserContext, type Page } from "playwright";
import type { Viewport } from "./recipe";

/** Launch system Google Chrome (channel: chrome) — no bundled-browser download needed. */
export async function launchBrowser(headless = true): Promise<Browser> {
  const noSandbox = process.env.SCREENSHOT_BOT_NO_SANDBOX === "1";
  return chromium.launch({
    channel: "chrome",
    headless,
    args: noSandbox ? ["--no-sandbox"] : [],
  });
}

export interface ContextOptions {
  viewport: Viewport;
  storageStatePath?: string;
  /** Default per-action timeout in ms (default 15000). Keeps broken steps from hanging. */
  timeoutMs?: number;
}

/** Create an isolated context (optionally with a saved session) and its first page. */
export async function newContext(
  browser: Browser,
  opts: ContextOptions,
): Promise<{ context: BrowserContext; page: Page }> {
  const context = await browser.newContext({
    viewport: opts.viewport,
    ...(opts.storageStatePath ? { storageState: opts.storageStatePath } : {}),
  });
  context.setDefaultTimeout(opts.timeoutMs ?? 15000);
  const page = await context.newPage();
  return { context, page };
}

export interface ContextProviderOptions {
  headless?: boolean;
  timeoutMs?: number;
  /** When set, use a persistent context on the real Chrome profile (already logged in). */
  profileDir?: string;
}

export interface ContextProvider {
  open(opts: ContextOptions): Promise<{ context: BrowserContext; page: Page }>;
  dispose(): Promise<void>;
}

/**
 * A per-recipe context factory. In profile mode each recipe gets a persistent
 * context bound to the real Chrome profile (no login needed); otherwise a fresh
 * incognito context (optionally seeded with a saved session) off one browser.
 *
 * Note: profile mode requires Chrome to be closed — a profile can't be driven by
 * two Chrome processes at once.
 */
export async function createContextProvider(
  opts: ContextProviderOptions,
): Promise<ContextProvider> {
  const headless = opts.headless ?? true;
  const timeoutMs = opts.timeoutMs ?? 15000;
  const noSandbox = process.env.SCREENSHOT_BOT_NO_SANDBOX === "1";
  const args = noSandbox ? ["--no-sandbox"] : [];

  if (opts.profileDir) {
    const profileDir = opts.profileDir;
    return {
      async open({ viewport }) {
        const context = await chromium.launchPersistentContext(profileDir, {
          channel: "chrome",
          headless,
          viewport,
          args,
        });
        context.setDefaultTimeout(timeoutMs);
        const page = context.pages()[0] ?? (await context.newPage());
        return { context, page };
      },
      async dispose() {
        /* each persistent context is closed per-recipe by the runner */
      },
    };
  }

  const browser = await chromium.launch({ channel: "chrome", headless, args });
  return {
    open: (o) => newContext(browser, { ...o, timeoutMs }),
    dispose: () => browser.close(),
  };
}
