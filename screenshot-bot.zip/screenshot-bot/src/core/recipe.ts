import { parse as parseYaml, stringify as stringifyYaml } from "yaml";

export interface Viewport {
  width: number;
  height: number;
}

export type Step =
  | { type: "goto"; url: string }
  | { type: "click"; selector: string }
  | { type: "fill"; selector: string; value: string }
  | { type: "waitFor"; target: string }
  | { type: "scroll"; target: string }
  | { type: "screenshot"; name: string }
  | { type: "press"; key: string }
  | { type: "select"; selector: string; value: string };

export interface Recipe {
  name: string;
  baseUrl: string;
  session?: string;
  viewport: Viewport;
  steps: Step[];
}

export const DEFAULT_VIEWPORT: Viewport = { width: 1440, height: 900 };

/** Steps whose YAML value is a plain string. */
const STRING_STEPS = {
  goto: "url",
  click: "selector",
  waitFor: "target",
  scroll: "target",
  screenshot: "name",
  press: "key",
} as const;

/** Steps whose YAML value is a `{ selector, value }` object. */
const OBJECT_STEPS = new Set(["fill", "select"]);

function normalizeStep(raw: unknown, index: number): Step {
  if (raw === null || typeof raw !== "object" || Array.isArray(raw)) {
    throw new Error(`Step ${index + 1} must be a mapping with a single step key`);
  }
  const keys = Object.keys(raw as Record<string, unknown>);
  if (keys.length !== 1) {
    throw new Error(
      `Step ${index + 1} must have exactly one step key, got: ${keys.join(", ") || "(none)"}`,
    );
  }
  const key = keys[0];
  const value = (raw as Record<string, unknown>)[key];

  if (key in STRING_STEPS) {
    const field = STRING_STEPS[key as keyof typeof STRING_STEPS];
    const str = key === "waitFor" ? String(value) : value;
    if (typeof str !== "string") {
      throw new Error(`Step ${index + 1} (${key}) expects a string value`);
    }
    return { type: key, [field]: str } as Step;
  }

  if (OBJECT_STEPS.has(key)) {
    const obj = value as Record<string, unknown> | null;
    if (!obj || typeof obj !== "object") {
      throw new Error(`Step ${index + 1} (${key}) expects { selector, value }`);
    }
    const { selector, value: v } = obj;
    if (typeof selector !== "string" || typeof v !== "string") {
      throw new Error(`Step ${index + 1} (${key}) expects string selector and value`);
    }
    return { type: key as "fill" | "select", selector, value: v };
  }

  throw new Error(`Step ${index + 1}: unknown step type "${key}"`);
}

/** Convert a normalized Step back into its single-key YAML form. */
function stepToNode(step: Step): Record<string, unknown> {
  switch (step.type) {
    case "goto":
      return { goto: step.url };
    case "click":
      return { click: step.selector };
    case "fill":
      return { fill: { selector: step.selector, value: step.value } };
    case "waitFor":
      return { waitFor: step.target };
    case "scroll":
      return { scroll: step.target };
    case "screenshot":
      return { screenshot: step.name };
    case "press":
      return { press: step.key };
    case "select":
      return { select: { selector: step.selector, value: step.value } };
  }
}

/** Serialize a Recipe to YAML that loadRecipe() can read back (round-trips). */
export function serializeRecipe(recipe: Recipe): string {
  return stringifyYaml({
    name: recipe.name,
    baseUrl: recipe.baseUrl,
    ...(recipe.session !== undefined ? { session: recipe.session } : {}),
    viewport: recipe.viewport,
    steps: recipe.steps.map(stepToNode),
  });
}

export function loadRecipe(yaml: string): Recipe {
  const doc = parseYaml(yaml) as Record<string, unknown> | null;
  if (!doc || typeof doc !== "object") {
    throw new Error("Recipe must be a YAML mapping");
  }

  const { name, baseUrl, session, viewport, steps } = doc;

  if (typeof name !== "string" || name.length === 0) {
    throw new Error('Recipe is missing a "name"');
  }
  if (typeof baseUrl !== "string" || baseUrl.length === 0) {
    throw new Error('Recipe is missing a "baseUrl"');
  }
  if (session !== undefined && typeof session !== "string") {
    throw new Error('Recipe "session" must be a string when present');
  }
  if (!Array.isArray(steps) || steps.length === 0) {
    throw new Error('Recipe must have a non-empty "steps" list');
  }

  let vp = DEFAULT_VIEWPORT;
  if (viewport !== undefined) {
    const v = viewport as Record<string, unknown>;
    if (typeof v?.width !== "number" || typeof v?.height !== "number") {
      throw new Error('Recipe "viewport" must be { width, height } numbers');
    }
    vp = { width: v.width, height: v.height };
  }

  return {
    name,
    baseUrl,
    ...(session !== undefined ? { session } : {}),
    viewport: vp,
    steps: steps.map(normalizeStep),
  };
}
