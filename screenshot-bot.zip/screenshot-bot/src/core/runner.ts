import { mkdir } from "node:fs/promises";
import { join } from "node:path";
import { createContextProvider } from "./browser";
import { storageStateFor } from "./session";
import { executeStep } from "./steps/index";
import { describeStep, type RunEvent } from "./events";
import type { Recipe } from "./recipe";

export interface RunOptions {
  runId: string;
  outputRoot: string;
  sessionsDir: string;
  headless?: boolean;
  timeoutMs?: number;
  /** Use the real Chrome profile at this dir (already logged in); ignores recipe.session. */
  profileDir?: string;
}

/**
 * Execute recipes deterministically, yielding a stream of RunEvents.
 * A broken step is logged (with a `-FAILED.png`) and the run continues.
 */
export async function* runRecipes(
  recipes: Recipe[],
  opts: RunOptions,
): AsyncGenerator<RunEvent> {
  yield { type: "runStart", runId: opts.runId, sites: recipes.map((r) => r.name) };

  const provider = await createContextProvider({
    ...(opts.headless !== undefined ? { headless: opts.headless } : {}),
    ...(opts.timeoutMs !== undefined ? { timeoutMs: opts.timeoutMs } : {}),
    ...(opts.profileDir ? { profileDir: opts.profileDir } : {}),
  });
  let totalSteps = 0;
  let totalFailed = 0;

  try {
    for (const recipe of recipes) {
      const outDir = join(opts.outputRoot, opts.runId, recipe.name);
      await mkdir(outDir, { recursive: true });
      yield {
        type: "siteStart",
        site: recipe.name,
        outDir,
        stepCount: recipe.steps.length,
      };

      // In profile mode the real profile provides auth, so recipe.session is ignored.
      const storageStatePath =
        !opts.profileDir && recipe.session
          ? await storageStateFor(opts.sessionsDir, recipe.session)
          : undefined;

      let context, page;
      try {
        ({ context, page } = await provider.open({
          viewport: recipe.viewport,
          ...(storageStatePath ? { storageStatePath } : {}),
        }));
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        totalFailed++;
        yield {
          type: "stepFailed",
          site: recipe.name,
          index: -1,
          label: "open browser context",
          error: opts.profileDir
            ? `${msg} (is Chrome open? Close it — the profile can't be used by two Chrome processes.)`
            : msg,
        };
        yield { type: "siteEnd", site: recipe.name, ok: 0, failed: 1 };
        continue;
      }

      let ok = 0;
      let failed = 0;
      const stepCtx = { baseUrl: recipe.baseUrl, outDir };

      for (let i = 0; i < recipe.steps.length; i++) {
        const step = recipe.steps[i];
        const label = describeStep(step);
        yield { type: "stepStart", site: recipe.name, index: i, label };
        const start = Date.now();
        try {
          const res = await executeStep(page, step, stepCtx);
          ok++;
          totalSteps++;
          yield {
            type: "stepDone",
            site: recipe.name,
            index: i,
            label,
            durationMs: Date.now() - start,
            ...(res.screenshot ? { screenshot: res.screenshot } : {}),
          };
        } catch (err) {
          failed++;
          totalSteps++;
          totalFailed++;
          const shot = `step-${i + 1}-FAILED.png`;
          try {
            await page.screenshot({ path: join(outDir, shot), fullPage: true });
          } catch {
            /* best-effort */
          }
          yield {
            type: "stepFailed",
            site: recipe.name,
            index: i,
            label,
            error: err instanceof Error ? err.message : String(err),
            screenshot: shot,
          };
        }
      }

      await context.close();
      yield { type: "siteEnd", site: recipe.name, ok, failed };
    }
  } finally {
    await provider.dispose();
  }

  yield {
    type: "runEnd",
    summary: { sites: recipes.length, totalSteps, totalFailed },
  };
}
