import { fileURLToPath } from "node:url";
import { dirname, join, resolve } from "node:path";

/** Project root = two levels up from src/core. */
const PROJECT_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..", "..");

function dir(envKey: string, fallback: string): string {
  return process.env[envKey] ? resolve(process.env[envKey]!) : join(PROJECT_ROOT, fallback);
}

export const RECIPES_DIR = dir("SCREENSHOT_BOT_RECIPES_DIR", "recipes");
export const SESSIONS_DIR = dir("SCREENSHOT_BOT_SESSIONS_DIR", "sessions");
export const OUTPUT_DIR = dir("SCREENSHOT_BOT_OUTPUT_DIR", "output");

/** A filesystem-friendly run id like 20260702-143000. */
export function makeRunId(now: Date = new Date()): string {
  const p = (n: number) => String(n).padStart(2, "0");
  return (
    `${now.getFullYear()}${p(now.getMonth() + 1)}${p(now.getDate())}` +
    `-${p(now.getHours())}${p(now.getMinutes())}${p(now.getSeconds())}`
  );
}
