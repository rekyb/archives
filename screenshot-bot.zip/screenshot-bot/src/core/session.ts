import { mkdir, stat } from "node:fs/promises";
import { join } from "node:path";
import type { BrowserContext } from "playwright";

export interface SessionInfo {
  exists: boolean;
  mtime?: Date;
}

/** Path to a saved session (Playwright storageState) file. */
export function sessionPath(dir: string, name: string): string {
  return join(dir, `${name}.json`);
}

/** Whether a session exists and, if so, when it was last saved. */
export async function sessionInfo(dir: string, name: string): Promise<SessionInfo> {
  try {
    const s = await stat(sessionPath(dir, name));
    return { exists: true, mtime: s.mtime };
  } catch {
    return { exists: false };
  }
}

/** Save the browser context's cookies + localStorage as a reusable session. */
export async function saveSession(
  context: BrowserContext,
  dir: string,
  name: string,
): Promise<string> {
  await mkdir(dir, { recursive: true });
  const path = sessionPath(dir, name);
  await context.storageState({ path });
  return path;
}

/** Returns the session file path if it exists, else undefined (for context creation). */
export async function storageStateFor(
  dir: string,
  name: string,
): Promise<string | undefined> {
  return (await sessionInfo(dir, name)).exists ? sessionPath(dir, name) : undefined;
}
