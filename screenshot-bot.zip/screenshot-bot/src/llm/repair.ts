import { mkdir, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { generateText, type LanguageModelV1 } from "ai";
import { z } from "zod";
import { launchBrowser, newContext } from "../core/browser";
import { describeStep } from "../core/events";
import { DEFAULT_VIEWPORT, serializeRecipe, type Step } from "../core/recipe";
import { loadRecipeByName } from "../core/recipes-dir";
import { storageStateFor } from "../core/session";
import { executeStep } from "../core/steps";
import { resolveLlmConfig } from "./config";
import { getModel } from "./provider";
import { selectorResolves, stepSelector } from "./recipe-build";

export interface RepairOptions {
  name: string;
  recipesDir: string;
  sessionsDir: string;
  failedLabel?: string;
  onLog?: (m: string) => void;
  model?: LanguageModelV1;
}

export interface RepairResult {
  path: string;
}

/** Produce a copy of a step with its selector replaced. */
function withSelector(step: Step, selector: string): Step {
  switch (step.type) {
    case "click":
      return { type: "click", selector };
    case "fill":
      return { type: "fill", selector, value: step.value };
    case "select":
      return { type: "select", selector, value: step.value };
    default:
      return step;
  }
}

async function distillElements(page: import("playwright").Page): Promise<string> {
  const els = await page
    .evaluate(() => {
      const out: string[] = [];
      const nodes = document.querySelectorAll(
        "a, button, input, select, textarea, [role=button]",
      );
      for (const el of Array.from(nodes).slice(0, 200)) {
        const tag = el.tagName.toLowerCase();
        const id = el.getAttribute("id");
        const name = el.getAttribute("name");
        let selector = "";
        if (id) selector = `#${id}`;
        else if (name) selector = `${tag}[name="${name}"]`;
        else {
          const t = (el.textContent || "").trim();
          if (t) selector = `text=${t.slice(0, 40)}`;
        }
        if (!selector) continue;
        const text = (el.textContent || "").trim().slice(0, 60);
        out.push(`- <${tag}> ${JSON.stringify(text)} -> ${selector}`);
        if (out.length >= 40) break;
      }
      return out;
    })
    .catch(() => [] as string[]);
  return els.length ? els.join("\n") : "(no interactive elements detected)";
}

/**
 * Repair a recipe by executing it until a step breaks, then asking the model
 * (single-shot, with the broken page state) for a corrected selector, validating
 * the proposal, patching the step, and writing the recipe back.
 */
export async function repairRecipe(opts: RepairOptions): Promise<RepairResult> {
  const log = opts.onLog ?? (() => {});
  const path = join(opts.recipesDir, `${opts.name}.yaml`);
  const recipe = await loadRecipeByName(opts.recipesDir, opts.name);

  let model = opts.model;
  if (!model) {
    const config = resolveLlmConfig();
    if (!config) {
      throw new Error(
        "LLM is not configured. Set SCREENSHOT_BOT_LLM_PROVIDER and the matching API key.",
      );
    }
    model = getModel(config);
  }

  const browser = await launchBrowser(true);
  const scratchDir = join(tmpdir(), `screenshot-bot-repair-${opts.name}`);

  try {
    await mkdir(scratchDir, { recursive: true });
    const storageStatePath = await storageStateFor(opts.sessionsDir, opts.name);
    const { context, page } = await newContext(browser, {
      viewport: recipe.viewport ?? DEFAULT_VIEWPORT,
      storageStatePath,
    });

    const ctx = { baseUrl: recipe.baseUrl, outDir: scratchDir };
    let brokenIndex = -1;

    for (let i = 0; i < recipe.steps.length; i++) {
      const step = recipe.steps[i];
      const label = describeStep(step);
      const isTargetLabel =
        opts.failedLabel !== undefined && label === opts.failedLabel;
      try {
        await executeStep(page, step, ctx);
        if (isTargetLabel) {
          // Caller flagged this step as broken even though it executed.
          brokenIndex = i;
          break;
        }
      } catch (err) {
        log(`step ${i + 1} failed: ${label}: ${(err as Error).message}`);
        brokenIndex = i;
        break;
      }
    }

    if (brokenIndex === -1) {
      log("No broken step found; recipe unchanged.");
      await context.close();
      return { path };
    }

    const broken = recipe.steps[brokenIndex];
    const brokenSelector = stepSelector(broken);
    if (brokenSelector === undefined) {
      log(`Broken step ${brokenIndex + 1} has no selector to repair; unchanged.`);
      await context.close();
      return { path };
    }

    let repaired: string | undefined;
    for (let attempt = 0; attempt < 3 && !repaired; attempt++) {
      let shot: Buffer | undefined;
      try {
        shot = await page.screenshot();
      } catch {
        shot = undefined;
      }
      const elements = await distillElements(page);

      const content: import("ai").CoreUserMessage["content"] = [
        {
          type: "text",
          text:
            `The recipe step "${describeStep(broken)}" failed because its selector ` +
            `"${brokenSelector}" no longer resolves on ${page.url()}.\n` +
            `Interactive elements:\n${elements}\n\n` +
            "Reply with a single corrected Playwright selector for this step.",
        },
      ];
      if (shot) content.push({ type: "image", image: shot });

      const result = await generateText({
        model,
        system:
          "You fix broken Playwright selectors in a screenshot recipe. " +
          "Return only the corrected selector via the tool.",
        messages: [{ role: "user", content }],
        tools: {
          proposeSelector: {
            description: "Propose a corrected Playwright selector for the broken step.",
            parameters: z.object({ selector: z.string() }),
          },
        },
        toolChoice: { type: "tool", toolName: "proposeSelector" },
        maxSteps: 1,
      });

      const call = result.toolCalls.find((c) => c.toolName === "proposeSelector");
      const proposed = (call?.args as { selector?: string } | undefined)?.selector;
      if (!proposed) {
        log(`attempt ${attempt + 1}: model proposed no selector`);
        continue;
      }
      if (await selectorResolves(page, proposed)) {
        repaired = proposed;
        log(`attempt ${attempt + 1}: accepted selector ${proposed}`);
      } else {
        log(`attempt ${attempt + 1}: proposed selector ${proposed} does not resolve`);
      }
    }

    await context.close();

    if (!repaired) {
      log("Could not find a working selector; recipe unchanged.");
      return { path };
    }

    recipe.steps[brokenIndex] = withSelector(broken, repaired);
    await writeFile(path, serializeRecipe(recipe), "utf8");
    log(`Patched step ${brokenIndex + 1} and wrote ${path}`);
  } finally {
    await browser.close();
  }

  return { path };
}
