import { mkdir, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { generateText, tool, type LanguageModelV1 } from "ai";
import { z } from "zod";
import { createContextProvider } from "../core/browser";
import { DEFAULT_VIEWPORT, serializeRecipe, type Recipe, type Step } from "../core/recipe";
import { storageStateFor } from "../core/session";
import { executeStep } from "../core/steps";
import { resolveLlmConfig } from "./config";
import { getModel } from "./provider";
import { buildRecipe, normalizeRawStep, selectorResolves, stepSelector } from "./recipe-build";

export interface AuthorOptions {
  name: string;
  baseUrl?: string;
  goal?: string;
  recipesDir: string;
  sessionsDir: string;
  onLog?: (m: string) => void;
  /** Injected AI SDK model (tests). When set, real config resolution is skipped. */
  model?: LanguageModelV1;
  maxModelSteps?: number;
  /** Use the real Chrome profile at this dir (already logged in); ignores saved session. */
  profileDir?: string;
}

export interface AuthorResult {
  path: string;
  recipe: Recipe;
}

const DEFAULT_GOAL =
  "Navigate this site and capture the key screens a benchmarker would want; produce recipe steps.";

const stepShape = z.object({
  type: z.string().describe("goto|click|fill|waitFor|scroll|screenshot|press|select"),
  url: z.string().optional(),
  selector: z.string().optional(),
  value: z.string().optional(),
  target: z.string().optional(),
  name: z.string().optional(),
  key: z.string().optional(),
});

interface PageElement {
  selector: string;
  text: string;
  tag: string;
}

/** Collect a distilled, capped list of interactive elements with robust selector candidates. */
async function distillElements(page: import("playwright").Page): Promise<PageElement[]> {
  return page.evaluate(() => {
    const out: { selector: string; text: string; tag: string }[] = [];
    const nodes = document.querySelectorAll("a, button, input, select, textarea, [role=button]");
    for (const el of Array.from(nodes).slice(0, 200)) {
      const tag = el.tagName.toLowerCase();
      let selector = "";
      const id = el.getAttribute("id");
      const name = el.getAttribute("name");
      const testid = el.getAttribute("data-testid");
      if (id) selector = `#${id}`;
      else if (testid) selector = `[data-testid="${testid}"]`;
      else if (name) selector = `${tag}[name="${name}"]`;
      else {
        const text = (el.textContent || "").trim();
        if (text) selector = `text=${text.slice(0, 40)}`;
      }
      if (!selector) continue;
      const text = (el.textContent || (el as HTMLInputElement).value || "").trim().slice(0, 60);
      out.push({ selector, text, tag });
      if (out.length >= 40) break;
    }
    return out;
  });
}

function renderElements(els: PageElement[]): string {
  if (els.length === 0) return "(no interactive elements detected)";
  return els.map((e) => `- <${e.tag}> ${JSON.stringify(e.text)} -> ${e.selector}`).join("\n");
}

/**
 * Author a recipe agentically: drive a headless browser under model control,
 * validating every selector-bearing step before recording it, then serialize
 * the collected steps to `recipesDir/<name>.yaml`.
 */
export async function authorRecipe(opts: AuthorOptions): Promise<AuthorResult> {
  const log = opts.onLog ?? (() => {});
  const maxSteps = opts.maxModelSteps ?? 20;

  let model = opts.model;
  if (!model) {
    const config = resolveLlmConfig();
    if (!config) {
      throw new Error(
        "LLM is not configured. Set SCREENSHOT_BOT_LLM_PROVIDER and the matching API key.",
      );
    }
    log(`Using ${config.provider} model ${config.model}`);
    model = getModel(config);
  }

  const provider = await createContextProvider({
    headless: true,
    ...(opts.profileDir ? { profileDir: opts.profileDir } : {}),
  });
  const collected: Step[] = [];
  const baseUrl = opts.baseUrl ?? "";
  // Scratch dir so addStep-driven screenshots (if executed) have somewhere to go.
  const scratchDir = join(tmpdir(), `screenshot-bot-author-${opts.name}`);

  try {
    await mkdir(scratchDir, { recursive: true });
    const storageStatePath = opts.profileDir
      ? undefined
      : await storageStateFor(opts.sessionsDir, opts.name);
    const { context, page } = await provider.open({
      viewport: DEFAULT_VIEWPORT,
      ...(storageStatePath ? { storageStatePath } : {}),
    });

    if (baseUrl) {
      log(`goto ${baseUrl}`);
      await page.goto(baseUrl, { waitUntil: "load" });
      collected.push({ type: "goto", url: baseUrl });
    }

    let finished = false;

    const record = (step: Step) => {
      collected.push(step);
      log(`recorded ${step.type}`);
    };

    /** Validate a selector-bearing step, returning an error string or null. */
    const validate = async (step: Step): Promise<string | null> => {
      const sel = stepSelector(step);
      if (sel === undefined) return null;
      const ok = await selectorResolves(page, sel);
      return ok ? null : `Selector "${sel}" did not resolve on ${page.url()}. Try another.`;
    };

    const tools = {
      navigate: tool({
        description: "Navigate the browser to a URL (recorded as a goto step).",
        parameters: z.object({ url: z.string() }),
        execute: async ({ url }) => {
          try {
            const target = new URL(url, baseUrl || undefined).toString();
            await page.goto(target, { waitUntil: "load" });
            record({ type: "goto", url });
            return `Navigated to ${page.url()}`;
          } catch (err) {
            return `Navigation failed: ${(err as Error).message}`;
          }
        },
      }),
      click: tool({
        description: "Click an element by Playwright selector (validated before recording).",
        parameters: z.object({ selector: z.string() }),
        execute: async ({ selector }) => {
          const step: Step = { type: "click", selector };
          const err = await validate(step);
          if (err) return err;
          try {
            await page.locator(selector).first().click();
          } catch (e) {
            return `Click failed: ${(e as Error).message}`;
          }
          record(step);
          return `Clicked ${selector}; now at ${page.url()}`;
        },
      }),
      capture: tool({
        description: "Record a screenshot step with the given name.",
        parameters: z.object({ name: z.string() }),
        execute: async ({ name }) => {
          record({ type: "screenshot", name });
          return `Recorded screenshot "${name}"`;
        },
      }),
      addStep: tool({
        description:
          "Record a recipe step. Provide { step: { type, ... } } matching a recipe step form.",
        parameters: z.object({ step: stepShape }),
        execute: async ({ step: raw }) => {
          let step: Step;
          try {
            step = normalizeRawStep(raw);
          } catch (e) {
            return `Invalid step: ${(e as Error).message}`;
          }
          const err = await validate(step);
          if (err) return err;
          // Best-effort execution so the page advances for subsequent turns.
          if (step.type !== "screenshot") {
            try {
              await executeStep(page, step, { baseUrl, outDir: scratchDir });
            } catch {
              /* non-fatal: recording still happens */
            }
          }
          record(step);
          return `Recorded ${step.type}`;
        },
      }),
      finish: tool({
        description: "Signal that authoring is complete.",
        parameters: z.object({}),
        execute: async () => {
          finished = true;
          return "Finished.";
        },
      }),
    };

    const system =
      `You are authoring a browser screenshot recipe. Goal: ${opts.goal ?? DEFAULT_GOAL}\n` +
      "Each turn you receive a screenshot and a list of interactive elements. " +
      "Use navigate/click to move, capture to take screenshots, addStep for other steps " +
      "(fill/select/press/scroll/waitFor), and finish when done. Prefer robust selectors. " +
      "If a selector is rejected, pick a better one from the elements list.";

    const messages: import("ai").CoreMessage[] = [];

    for (let i = 0; i < maxSteps && !finished; i++) {
      let shot: Buffer | undefined;
      try {
        shot = await page.screenshot();
      } catch {
        shot = undefined;
      }
      const els = await distillElements(page).catch(() => [] as PageElement[]);

      const content: import("ai").CoreUserMessage["content"] = [
        {
          type: "text",
          text: `Current URL: ${page.url()}\nInteractive elements:\n${renderElements(els)}`,
        },
      ];
      if (shot) content.push({ type: "image", image: shot });
      messages.push({ role: "user", content });

      const result = await generateText({
        model,
        system,
        messages,
        tools,
        maxSteps: 1,
        toolChoice: "required",
      });
      messages.push(...result.response.messages);
    }

    await context.close();
  } finally {
    await provider.dispose();
  }

  const recipe = buildRecipe({
    name: opts.name,
    baseUrl,
    viewport: DEFAULT_VIEWPORT,
    steps: collected,
  });

  await mkdir(opts.recipesDir, { recursive: true });
  const path = join(opts.recipesDir, `${opts.name}.yaml`);
  await writeFile(path, serializeRecipe(recipe), "utf8");
  log(`Wrote recipe to ${path}`);

  return { path, recipe };
}
