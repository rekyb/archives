import { anthropic } from "@ai-sdk/anthropic";
import { openai } from "@ai-sdk/openai";
import { createGoogleGenerativeAI } from "@ai-sdk/google";
import type { LanguageModelV1 } from "ai";
import type { LlmConfig, LlmProvider } from "./config";

/** Google reads GOOGLE_GENERATIVE_AI_API_KEY by default; also accept GEMINI_API_KEY. */
function googleModel(model: string): LanguageModelV1 {
  const apiKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_GENERATIVE_AI_API_KEY;
  const google = createGoogleGenerativeAI(apiKey ? { apiKey } : {});
  return google(model);
}

/**
 * Multi-provider model registry. This is the only module that imports the
 * provider SDKs, so swapping/adding providers stays localized here.
 */
const REGISTRY: Record<LlmProvider, (model: string) => LanguageModelV1> = {
  anthropic: (model) => anthropic(model),
  openai: (model) => openai(model),
  google: (model) => googleModel(model),
};

/** Return an AI SDK model instance for the resolved config. */
export function getModel(config: LlmConfig): LanguageModelV1 {
  const make = REGISTRY[config.provider];
  if (!make) {
    throw new Error(`Unsupported LLM provider: ${config.provider}`);
  }
  return make(config.model);
}
