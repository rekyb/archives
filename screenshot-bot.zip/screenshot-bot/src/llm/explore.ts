import type { LanguageModelV1 } from "ai";
import { executeRun } from "../core/execute";
import type { RunEvent } from "../core/events";
import type { Recipe } from "../core/recipe";
import { authorRecipe } from "./author";

export interface ExploreOptions {
  /** Recipe name to write and run (e.g. a site slug). */
  name: string;
  baseUrl: string;
  goal?: string;
  recipesDir: string;
  sessionsDir: string;
  outputRoot: string;
  runId: string;
  headless?: boolean;
  /** Use the real Chrome profile at this dir (already logged in). */
  profileDir?: string;
  onLog?: (m: string) => void;
  onEvent?: (e: RunEvent) => void;
  /** Injected AI SDK model (tests). */
  model?: LanguageModelV1;
  maxModelSteps?: number;
}

export interface ExploreResult {
  recipePath: string;
  recipe: Recipe;
  runId: string;
}

/**
 * Full LLM mode: the model explores the site with no pre-existing recipe and
 * decides what to capture, producing a recipe; that recipe is then replayed
 * deterministically to capture the screenshots + logs. You keep the recipe, so
 * subsequent runs need no LLM at all.
 */
export async function exploreAndCapture(opts: ExploreOptions): Promise<ExploreResult> {
  const log = opts.onLog ?? (() => {});

  log(`Exploring ${opts.baseUrl} with the LLM…`);
  const { path: recipePath, recipe } = await authorRecipe({
    name: opts.name,
    baseUrl: opts.baseUrl,
    ...(opts.goal ? { goal: opts.goal } : {}),
    recipesDir: opts.recipesDir,
    sessionsDir: opts.sessionsDir,
    onLog: log,
    ...(opts.model ? { model: opts.model } : {}),
    ...(opts.maxModelSteps !== undefined ? { maxModelSteps: opts.maxModelSteps } : {}),
    ...(opts.profileDir ? { profileDir: opts.profileDir } : {}),
  });
  log(`Recipe written to ${recipePath}; replaying to capture screenshots…`);

  await executeRun([recipe], {
    runId: opts.runId,
    outputRoot: opts.outputRoot,
    sessionsDir: opts.sessionsDir,
    ...(opts.headless !== undefined ? { headless: opts.headless } : {}),
    ...(opts.profileDir ? { profileDir: opts.profileDir } : {}),
    ...(opts.onEvent ? { onEvent: opts.onEvent } : {}),
  });

  return { recipePath, recipe, runId: opts.runId };
}
