import type { Page } from "playwright";
import { DEFAULT_VIEWPORT, type Recipe, type Step, type Viewport } from "../core/recipe";

/**
 * Return the selector a step depends on, or undefined for steps whose value is
 * a keyword/URL/name rather than a page selector. `waitFor`/`scroll` targets can
 * be keywords (`networkidle`, `top`, `bottom`, a number) so they are not treated
 * as strict selectors here.
 */
export function stepSelector(step: Step): string | undefined {
  switch (step.type) {
    case "click":
    case "fill":
    case "select":
      return step.selector;
    default:
      return undefined;
  }
}

/**
 * Whether a selector resolves to at least one element on the current page.
 * Uses a short wait so a not-yet-rendered element still counts, but a bad
 * selector fails fast.
 */
export async function selectorResolves(
  page: Page,
  selector: string,
  timeoutMs = 2000,
): Promise<boolean> {
  try {
    if ((await page.locator(selector).count()) > 0) return true;
    await page.locator(selector).first().waitFor({ state: "attached", timeout: timeoutMs });
    return true;
  } catch {
    return false;
  }
}

/** Loosely-typed step as it arrives from a model tool call. */
export type RawStep = {
  type?: unknown;
  url?: unknown;
  selector?: unknown;
  value?: unknown;
  target?: unknown;
  name?: unknown;
  key?: unknown;
};

function str(v: unknown, field: string, type: string): string {
  if (typeof v !== "string" || v.length === 0) {
    throw new Error(`Step "${type}" requires a non-empty "${field}"`);
  }
  return v;
}

/** Normalize a loosely-typed step object into a validated Recipe Step (throws on bad shape). */
export function normalizeRawStep(raw: RawStep): Step {
  const type = raw.type;
  switch (type) {
    case "goto":
      return { type, url: str(raw.url, "url", type) };
    case "click":
      return { type, selector: str(raw.selector, "selector", type) };
    case "fill":
      return {
        type,
        selector: str(raw.selector, "selector", type),
        value: str(raw.value, "value", type),
      };
    case "select":
      return {
        type,
        selector: str(raw.selector, "selector", type),
        value: str(raw.value, "value", type),
      };
    case "waitFor":
      return { type, target: str(raw.target, "target", type) };
    case "scroll":
      return { type, target: str(raw.target, "target", type) };
    case "screenshot":
      return { type, name: str(raw.name, "name", type) };
    case "press":
      return { type, key: str(raw.key, "key", type) };
    default:
      throw new Error(`Unknown step type "${String(type)}"`);
  }
}

export interface BuildRecipeInput {
  name: string;
  baseUrl: string;
  steps: Step[];
  viewport?: Viewport;
  session?: string;
}

/** Assemble a Recipe object, guaranteeing a non-empty steps list and a viewport. */
export function buildRecipe(input: BuildRecipeInput): Recipe {
  if (input.steps.length === 0) {
    throw new Error("Cannot build a recipe with zero steps");
  }
  return {
    name: input.name,
    baseUrl: input.baseUrl,
    ...(input.session !== undefined ? { session: input.session } : {}),
    viewport: input.viewport ?? DEFAULT_VIEWPORT,
    steps: input.steps,
  };
}
