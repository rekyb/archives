/**
 * Optional multi-provider LLM configuration.
 *
 * Resolution is driven by environment variables so the TUI/CLI can enable the
 * LLM features only when a provider + key are actually available.
 */

export type LlmProvider = "anthropic" | "openai" | "google";

export const LLM_PROVIDERS: LlmProvider[] = ["anthropic", "openai", "google"];

export interface LlmConfig {
  provider: LlmProvider;
  model: string;
}

/**
 * Sensible default model per provider. The Anthropic id was confirmed against
 * the current model catalog (do not guess) — `claude-opus-4-8` is the current
 * most-capable Opus-tier model. OpenAI uses `gpt-4o`. Google uses
 * `gemini-2.5-flash` (fast, multimodal + tool-calling). Override any of these
 * with SCREENSHOT_BOT_LLM_MODEL.
 */
const DEFAULT_MODEL: Record<LlmProvider, string> = {
  anthropic: "claude-opus-4-8",
  openai: "gpt-4o",
  google: "gemini-2.5-flash",
};

/** Primary key name shown in messages. Google also accepts GEMINI_API_KEY. */
const PROVIDER_ENV_KEY: Record<LlmProvider, string> = {
  anthropic: "ANTHROPIC_API_KEY",
  openai: "OPENAI_API_KEY",
  google: "GEMINI_API_KEY",
};

/** All env var names that can supply a given provider's key. */
const PROVIDER_KEY_CANDIDATES: Record<LlmProvider, string[]> = {
  anthropic: ["ANTHROPIC_API_KEY"],
  openai: ["OPENAI_API_KEY"],
  google: ["GEMINI_API_KEY", "GOOGLE_GENERATIVE_AI_API_KEY"],
};

function hasKey(provider: LlmProvider): boolean {
  return PROVIDER_KEY_CANDIDATES[provider].some((k) => {
    const v = process.env[k];
    return typeof v === "string" && v.length > 0;
  });
}

function parseProvider(raw: string | undefined): LlmProvider | undefined {
  if (raw === "anthropic" || raw === "openai" || raw === "google") return raw;
  if (raw === "gemini") return "google"; // friendly alias
  return undefined;
}

/**
 * Resolve the effective LLM config from the environment, or null when the LLM
 * features should stay disabled.
 *
 * - `SCREENSHOT_BOT_LLM_PROVIDER` selects the provider (anthropic|openai).
 * - `SCREENSHOT_BOT_LLM_MODEL` optionally overrides the model.
 * - The matching provider key must be present, else returns null.
 * - If the provider env is unset but exactly one provider key is present, that
 *   provider is inferred.
 */
export function resolveLlmConfig(): LlmConfig | null {
  const requested = parseProvider(process.env.SCREENSHOT_BOT_LLM_PROVIDER);
  const modelOverride = process.env.SCREENSHOT_BOT_LLM_MODEL;

  let provider: LlmProvider | undefined = requested;

  if (provider === undefined) {
    // Infer only when exactly one provider key is present.
    const present = LLM_PROVIDERS.filter(hasKey);
    if (present.length === 1) provider = present[0];
  }

  if (provider === undefined) return null;
  if (!hasKey(provider)) return null;

  const model =
    modelOverride && modelOverride.length > 0 ? modelOverride : DEFAULT_MODEL[provider];

  return { provider, model };
}

export interface LlmStatus {
  available: boolean;
  provider?: string;
  model?: string;
  reason?: string;
}

/** Human-readable status for the TUI to explain why LLM features are on/off. */
export function llmStatus(): LlmStatus {
  const requested = process.env.SCREENSHOT_BOT_LLM_PROVIDER;
  const config = resolveLlmConfig();

  if (config) {
    return { available: true, provider: config.provider, model: config.model };
  }

  const parsed = parseProvider(requested);
  if (requested && !parsed) {
    return {
      available: false,
      reason: `Unknown SCREENSHOT_BOT_LLM_PROVIDER "${requested}" (expected "anthropic", "openai", or "google"/"gemini")`,
    };
  }
  if (parsed) {
    return {
      available: false,
      reason: `Missing ${PROVIDER_ENV_KEY[parsed]} for provider "${parsed}"`,
    };
  }
  return {
    available: false,
    reason:
      "No LLM provider configured. Set SCREENSHOT_BOT_LLM_PROVIDER and the matching API key (ANTHROPIC_API_KEY, OPENAI_API_KEY, or GEMINI_API_KEY).",
  };
}
