#!/usr/bin/env -S npx tsx
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { extractOption, takeFlag } from "./cli-args";
import { loadRecipeByName, loadRecipes } from "./core/recipes-dir";
import { resolveProfileDir } from "./core/profile";
import { executeRun } from "./core/execute";
import { loginFlow } from "./core/login";
import { inspectFlow } from "./core/inspect";
import { makeRunId, OUTPUT_DIR, RECIPES_DIR, SESSIONS_DIR } from "./core/paths";
import type { RunEvent } from "./core/events";

function printEvent(e: RunEvent): void {
  switch (e.type) {
    case "siteStart":
      process.stdout.write(`\n▸ ${e.site} (${e.stepCount} steps) → ${e.outDir}\n`);
      break;
    case "stepDone":
      process.stdout.write(
        `  ✓ ${e.label} (${e.durationMs}ms)${e.screenshot ? ` → ${e.screenshot}` : ""}\n`,
      );
      break;
    case "stepFailed":
      process.stdout.write(`  ✗ ${e.label}: ${e.error} → ${e.screenshot}\n`);
      break;
    case "runEnd":
      process.stdout.write(
        `\n${e.summary.sites} site(s), ${e.summary.totalSteps} step(s), ${e.summary.totalFailed} failed\n`,
      );
      break;
  }
}

async function cmdRun(names: string[], profileDir?: string): Promise<void> {
  const recipes = await loadRecipes(RECIPES_DIR, names);
  if (recipes.length === 0) {
    console.error(`No recipes found in ${RECIPES_DIR}`);
    process.exitCode = 1;
    return;
  }
  const runId = makeRunId();
  if (profileDir) console.log(`Using Chrome profile: ${profileDir} (close Chrome first)`);
  await executeRun(recipes, {
    runId,
    outputRoot: OUTPUT_DIR,
    sessionsDir: SESSIONS_DIR,
    headless: true,
    ...(profileDir ? { profileDir } : {}),
    onEvent: printEvent,
  });
  console.log(`\nOutput: ${OUTPUT_DIR}/${runId}`);
}

async function cmdLogin(name: string): Promise<void> {
  if (!name) throw new Error("usage: login <recipe>");
  const recipe = await loadRecipeByName(RECIPES_DIR, name);
  const path = await loginFlow(recipe, SESSIONS_DIR);
  console.log(`Session saved: ${path}`);
}

async function cmdInspect(name: string, url?: string): Promise<void> {
  if (!name) throw new Error("usage: inspect <recipe> [url]");
  const recipe = await loadRecipeByName(RECIPES_DIR, name);
  await inspectFlow(recipe, SESSIONS_DIR, url);
}

/** Explicit --instruction flag, else the SCREENSHOT_BOT_LLM_INSTRUCTION env default. */
function resolveInstruction(explicit?: string): string | undefined {
  const env = process.env.SCREENSHOT_BOT_LLM_INSTRUCTION;
  return explicit ?? (env && env.length > 0 ? env : undefined);
}

async function cmdAuthor(name: string, baseUrl?: string, instruction?: string): Promise<void> {
  if (!name) throw new Error("usage: author <recipe> [baseUrl] [--instruction '…']");
  const { authorRecipe } = await import("./llm/author");
  const goal = resolveInstruction(instruction);
  const res = await authorRecipe({
    name,
    ...(baseUrl ? { baseUrl } : {}),
    ...(goal ? { goal } : {}),
    recipesDir: RECIPES_DIR,
    sessionsDir: SESSIONS_DIR,
    onLog: (m) => console.log(m),
  });
  console.log(`Recipe written: ${res.path}`);
}

function slugFromUrl(url: string): string {
  try {
    return new URL(/^https?:\/\//.test(url) ? url : `https://${url}`).hostname
      .replace(/^www\./, "")
      .replace(/[^a-z0-9]+/gi, "-")
      .replace(/^-|-$/g, "");
  } catch {
    return "site";
  }
}

async function cmdExplore(
  baseUrl: string,
  name?: string,
  instruction?: string,
  profileDir?: string,
): Promise<void> {
  if (!baseUrl) throw new Error("usage: explore <baseUrl> [name] [--instruction '…'] [--profile]");
  const url = /^https?:\/\//.test(baseUrl) ? baseUrl : `https://${baseUrl}`;
  const { exploreAndCapture } = await import("./llm/explore");
  const goal = resolveInstruction(instruction);
  const runId = makeRunId();
  if (profileDir) console.log(`Using Chrome profile: ${profileDir} (close Chrome first)`);
  const res = await exploreAndCapture({
    name: name || slugFromUrl(url),
    baseUrl: url,
    ...(goal ? { goal } : {}),
    ...(profileDir ? { profileDir } : {}),
    recipesDir: RECIPES_DIR,
    sessionsDir: SESSIONS_DIR,
    outputRoot: OUTPUT_DIR,
    runId,
    headless: true,
    onLog: (m) => console.log(m),
    onEvent: printEvent,
  });
  console.log(`\nRecipe: ${res.recipePath}`);
  console.log(`Output: ${OUTPUT_DIR}/${runId}`);
}

async function cmdRepair(name: string): Promise<void> {
  if (!name) throw new Error("usage: repair <recipe>");
  const { repairRecipe } = await import("./llm/repair");
  const res = await repairRecipe({
    name,
    recipesDir: RECIPES_DIR,
    sessionsDir: SESSIONS_DIR,
    onLog: (m) => console.log(m),
  });
  console.log(`Recipe repaired: ${res.path}`);
}

/** Auto-load repo-root .env (gitignored) so `GEMINI_API_KEY` etc. are picked up. */
function loadDotEnv(): void {
  const envPath = join(dirname(dirname(fileURLToPath(import.meta.url))), ".env");
  try {
    process.loadEnvFile(envPath);
  } catch {
    /* no .env, or unreadable — fine */
  }
}

async function main(): Promise<void> {
  loadDotEnv();
  const [cmd, ...rest] = process.argv.slice(2);
  switch (cmd) {
    case undefined:
    case "tui": {
      const { startTui } = await import("./tui/app");
      await startTui();
      break;
    }
    case "run": {
      const { present: useProfile, rest: names } = takeFlag(rest, ["--profile"]);
      await cmdRun(names, useProfile ? resolveProfileDir() : undefined);
      break;
    }
    case "login":
      await cmdLogin(rest[0]);
      break;
    case "inspect":
      await cmdInspect(rest[0], rest[1]);
      break;
    case "author": {
      const { value: instr, rest: pos } = extractOption(rest, ["--instruction", "-i"]);
      await cmdAuthor(pos[0], pos[1], instr);
      break;
    }
    case "explore": {
      const { present: useProfile, rest: r1 } = takeFlag(rest, ["--profile"]);
      const { value: instr, rest: pos } = extractOption(r1, ["--instruction", "-i"]);
      await cmdExplore(pos[0], pos[1], instr, useProfile ? resolveProfileDir() : undefined);
      break;
    }
    case "repair":
      await cmdRepair(rest[0]);
      break;
    default:
      console.error(`Unknown command: ${cmd}`);
      console.error("Commands: tui (default), run [names…] [--profile], login <name>, inspect <name> [url], author <name> [baseUrl] [--instruction '…'], explore <baseUrl> [name] [--instruction '…'] [--profile], repair <name>");
      process.exitCode = 1;
  }
}

main().catch((err) => {
  console.error(err instanceof Error ? err.message : err);
  process.exitCode = 1;
});
