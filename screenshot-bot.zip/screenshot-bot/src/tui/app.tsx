import { useEffect, useState } from "react";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
import { readdir } from "node:fs/promises";
import { spawnSync } from "node:child_process";
import { Box, render, useApp, useInput } from "ink";
import { listRecipeNames } from "../core/recipes-dir";
import { RECIPES_DIR, SESSIONS_DIR } from "../core/paths";
import { loadLlmStatus, type LlmStatus } from "./llm";
import { takePendingCommand } from "./pending";
import { StatusBar } from "./components/StatusBar";
import { Dashboard } from "./screens/Dashboard";
import { RunScreen } from "./screens/RunScreen";
import { Sessions } from "./screens/Sessions";
import { Recipes } from "./screens/Recipes";
import { Output } from "./screens/Output";
import { Explore } from "./screens/Explore";
import type { Screen } from "./screens/types";

/** Project root = two levels up from src/tui. */
const PROJECT_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..", "..");

async function countSessions(): Promise<number> {
  try {
    return (await readdir(SESSIONS_DIR)).filter((f) => f.endsWith(".json")).length;
  } catch {
    return 0;
  }
}

function App() {
  const { exit } = useApp();
  const [screen, setScreen] = useState<Screen>("dashboard");
  const [recipeCount, setRecipeCount] = useState(0);
  const [sessionCount, setSessionCount] = useState(0);
  const [llm, setLlm] = useState<LlmStatus | null>(null);

  useEffect(() => {
    listRecipeNames(RECIPES_DIR).then((n) => setRecipeCount(n.length)).catch(() => {});
    countSessions().then(setSessionCount).catch(() => {});
    loadLlmStatus().then(setLlm).catch(() => setLlm({ available: false }));
  }, []);

  // Global keys: q/Esc returns to dashboard from a screen; q on the dashboard
  // exits. (Ctrl-C is handled by Ink itself.)
  useInput((input, key) => {
    if (screen === "dashboard") {
      if (input === "q") exit();
    } else if (input === "q" || key.escape) {
      setScreen("dashboard");
    }
  });

  const goHome = () => setScreen("dashboard");

  return (
    <Box flexDirection="column">
      <StatusBar recipes={recipeCount} sessions={sessionCount} llm={llm} />
      <Box marginTop={1}>
        {screen === "dashboard" && (
          <Dashboard onNavigate={setScreen} llmAvailable={llm?.available ?? false} />
        )}
        {screen === "run" && <RunScreen goHome={goHome} />}
        {screen === "sessions" && <Sessions goHome={goHome} />}
        {screen === "recipes" && <Recipes goHome={goHome} />}
        {screen === "output" && <Output goHome={goHome} />}
        {screen === "explore" && <Explore goHome={goHome} />}
      </Box>
    </Box>
  );
}

/**
 * Render the TUI. Uses a suspend->child->relaunch loop: after the Ink app
 * unmounts (a screen queued an interactive command and called exit()), we drain
 * the pending command and run it with stdio:"inherit" so the child fully owns
 * the terminal, then re-render the TUI. When nothing is queued, the loop ends.
 */
export async function startTui(): Promise<void> {
  // eslint-disable-next-line no-constant-condition
  while (true) {
    const instance = render(<App />);
    await instance.waitUntilExit();

    const pending = takePendingCommand();
    if (!pending) break;

    process.stdout.write(`\n▶ ${pending.label}\n`);
    spawnSync(pending.command, pending.args, {
      stdio: "inherit",
      cwd: PROJECT_ROOT,
    });
    process.stdout.write("\nReturning to control center…\n");
  }
}
