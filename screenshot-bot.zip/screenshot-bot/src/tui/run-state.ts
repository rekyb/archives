import type { RunEvent, RunSummary } from "../core/events";

/**
 * Pure event -> view-state reduction for the RunScreen. Keeping this a plain
 * function (no React) means it can be unit-tested with a scripted array of
 * RunEvents and reused verbatim by the live component via useReducer.
 */

export interface SiteProgress {
  site: string;
  stepCount: number;
  /** 1-based index of the step currently running (0 = not started yet). */
  current: number;
  currentLabel: string;
  ok: number;
  failed: number;
  done: boolean;
}

export interface RunViewState {
  runId?: string;
  sites: SiteProgress[];
  /** Full log history; the view renders only the last N lines. */
  log: string[];
  summary?: RunSummary;
  done: boolean;
}

export const initialRunState: RunViewState = {
  sites: [],
  log: [],
  done: false,
};

function upsertSite(
  sites: SiteProgress[],
  site: string,
  patch: (s: SiteProgress) => SiteProgress,
): SiteProgress[] {
  const idx = sites.findIndex((s) => s.site === site);
  if (idx === -1) {
    const blank: SiteProgress = {
      site,
      stepCount: 0,
      current: 0,
      currentLabel: "",
      ok: 0,
      failed: 0,
      done: false,
    };
    return [...sites, patch(blank)];
  }
  const next = sites.slice();
  next[idx] = patch(next[idx]);
  return next;
}

/** Reduce one RunEvent into the RunScreen view state. */
export function runReducer(state: RunViewState, event: RunEvent): RunViewState {
  switch (event.type) {
    case "runStart":
      return {
        ...state,
        runId: event.runId,
        log: [...state.log, `run ${event.runId} — ${event.sites.length} site(s)`],
      };

    case "siteStart":
      return {
        ...state,
        sites: upsertSite(state.sites, event.site, (s) => ({
          ...s,
          stepCount: event.stepCount,
        })),
        log: [...state.log, `▸ ${event.site} (${event.stepCount} steps)`],
      };

    case "stepStart":
      return {
        ...state,
        sites: upsertSite(state.sites, event.site, (s) => ({
          ...s,
          current: event.index + 1,
          currentLabel: event.label,
        })),
      };

    case "stepDone":
      return {
        ...state,
        sites: upsertSite(state.sites, event.site, (s) => ({
          ...s,
          ok: s.ok + 1,
        })),
        log: [...state.log, `  ✓ ${event.label} (${event.durationMs}ms)`],
      };

    case "stepFailed":
      return {
        ...state,
        sites: upsertSite(state.sites, event.site, (s) => ({
          ...s,
          failed: s.failed + 1,
        })),
        log: [...state.log, `  ✗ ${event.label}: ${event.error}`],
      };

    case "siteEnd":
      return {
        ...state,
        sites: upsertSite(state.sites, event.site, (s) => ({
          ...s,
          done: true,
        })),
        log: [...state.log, `✔ ${event.site}: ${event.ok} ok, ${event.failed} failed`],
      };

    case "runEnd":
      return {
        ...state,
        summary: event.summary,
        done: true,
        log: [
          ...state.log,
          `done — ${event.summary.sites} site(s), ${event.summary.totalSteps} step(s), ${event.summary.totalFailed} failed`,
        ],
      };

    default:
      return state;
  }
}
