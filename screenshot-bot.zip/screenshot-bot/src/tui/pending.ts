/**
 * "Suspend TUI -> run interactive child -> relaunch" plumbing.
 *
 * Ink owns stdin/stdout while mounted, so an interactive child process (login,
 * inspect, author, repair) cannot share the terminal cleanly. Instead a screen
 * records a PendingCommand here and calls useApp().exit(). startTui() runs its
 * render loop: after waitUntilExit() resolves it drains any pending command,
 * runs it with spawnSync({ stdio: "inherit" }) so the child fully owns the TTY,
 * then re-renders the TUI. If nothing is pending, the loop breaks and the TUI
 * exits for good.
 */

export interface PendingCommand {
  /** Human label shown before the child runs. */
  label: string;
  command: string;
  args: string[];
}

let pending: PendingCommand | null = null;

export function setPendingCommand(cmd: PendingCommand): void {
  pending = cmd;
}

/** Return and clear the queued command (null if none). */
export function takePendingCommand(): PendingCommand | null {
  const c = pending;
  pending = null;
  return c;
}
