/**
 * Lazy, failure-tolerant bridge to the optional LLM module at src/llm/config.
 * That module is built in parallel and may not exist yet at type-check time, so
 * we import it with a NON-LITERAL specifier: TypeScript treats `import(variable)`
 * as `Promise<any>` and performs no static resolution, so tsc never fails on a
 * missing file. Any failure (module absent, throws, wrong shape) => "off".
 */

export interface LlmStatus {
  available: boolean;
  provider?: string;
  model?: string;
  reason?: string;
}

export async function loadLlmStatus(): Promise<LlmStatus> {
  try {
    const specifier = "../llm/config";
    const mod = await import(specifier);
    const status = mod?.llmStatus?.();
    if (status && typeof status.available === "boolean") {
      return status as LlmStatus;
    }
    return { available: false, reason: "llm module has no llmStatus()" };
  } catch (err) {
    return {
      available: false,
      reason: err instanceof Error ? err.message : "llm module unavailable",
    };
  }
}
