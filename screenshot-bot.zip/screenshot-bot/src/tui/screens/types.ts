export type Screen =
  | "dashboard"
  | "run"
  | "sessions"
  | "recipes"
  | "output"
  | "explore";

export interface ScreenProps {
  /** Return to the dashboard. */
  goHome: () => void;
}
