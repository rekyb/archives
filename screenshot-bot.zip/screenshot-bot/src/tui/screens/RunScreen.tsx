import { useEffect, useReducer, useState } from "react";
import { Box, Text, useInput } from "ink";
import { loadRecipes, listRecipeNames } from "../../core/recipes-dir";
import { executeRun } from "../../core/execute";
import { makeRunId, OUTPUT_DIR, RECIPES_DIR, SESSIONS_DIR } from "../../core/paths";
import { resolveProfileDir } from "../../core/profile";
import { initialRunState, runReducer } from "../run-state";
import { ProgressList } from "../components/ProgressList";
import { LogView } from "../components/LogView";
import type { ScreenProps } from "./types";

type Phase = "select" | "running" | "done" | "error";

export function RunScreen({ goHome }: ScreenProps) {
  const [names, setNames] = useState<string[]>([]);
  const [cursor, setCursor] = useState(0);
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [phase, setPhase] = useState<Phase>("select");
  const [runId, setRunId] = useState<string>("");
  const [error, setError] = useState<string>("");
  // Local screen state read at launch time (kept out of the run reducer).
  const [useProfile, setUseProfile] = useState(false);
  const [state, dispatch] = useReducer(runReducer, initialRunState);

  useEffect(() => {
    listRecipeNames(RECIPES_DIR).then(setNames).catch(() => setNames([]));
  }, []);

  const start = () => {
    const chosen =
      selected.size > 0 ? names.filter((_, i) => selected.has(i)) : names;
    if (chosen.length === 0) return;
    const id = makeRunId();
    setRunId(id);
    setPhase("running");
    (async () => {
      try {
        const recipes = await loadRecipes(RECIPES_DIR, chosen);
        await executeRun(recipes, {
          runId: id,
          outputRoot: OUTPUT_DIR,
          sessionsDir: SESSIONS_DIR,
          headless: true,
          ...(useProfile ? { profileDir: resolveProfileDir() } : {}),
          onEvent: (e) => dispatch(e),
        });
        setPhase("done");
      } catch (err) {
        setError(err instanceof Error ? err.message : String(err));
        setPhase("error");
      }
    })();
  };

  useInput(
    (input, key) => {
      if (key.upArrow || input === "k") setCursor((c) => Math.max(0, c - 1));
      if (key.downArrow || input === "j")
        setCursor((c) => Math.min(names.length - 1, c + 1));
      if (input === " ") {
        setSelected((prev) => {
          const next = new Set(prev);
          if (next.has(cursor)) next.delete(cursor);
          else next.add(cursor);
          return next;
        });
      }
      if (input === "a") {
        setSelected((prev) =>
          prev.size === names.length ? new Set() : new Set(names.map((_, i) => i)),
        );
      }
      if (input === "p") setUseProfile((v) => !v);
      if (key.return) start();
    },
    { isActive: phase === "select" },
  );

  if (phase === "select") {
    return (
      <Box flexDirection="column">
        <Text bold color="cyan">
          Run a crawl
        </Text>
        <Text dimColor>
          space toggles · a toggles all · enter runs (all if none selected) · q back
        </Text>
        <Text>
          {useProfile ? "[x]" : "[ ]"} Use my Chrome profile (no login){" "}
          <Text dimColor>[p]</Text>
        </Text>
        {useProfile ? (
          <Text color="yellow">
            Chrome must be closed while running (a profile can&apos;t be used by two
            Chrome processes).
          </Text>
        ) : null}
        <Box flexDirection="column" marginTop={1}>
          {names.length === 0 ? (
            <Text dimColor>(no recipes found in {RECIPES_DIR})</Text>
          ) : (
            names.map((name, i) => (
              <Text key={name} color={i === cursor ? "cyan" : undefined}>
                {i === cursor ? "❯ " : "  "}
                {selected.has(i) ? "[x] " : "[ ] "}
                {name}
              </Text>
            ))
          )}
        </Box>
      </Box>
    );
  }

  return (
    <Box flexDirection="column">
      <Text bold color="cyan">
        Run {runId}
      </Text>
      <Box marginTop={1}>
        <ProgressList sites={state.sites} />
      </Box>
      <Box marginTop={1}>
        <LogView lines={state.log} max={12} />
      </Box>
      {phase === "error" ? (
        <Text color="red">error: {error}</Text>
      ) : state.summary ? (
        <Box flexDirection="column" marginTop={1}>
          <Text color={state.summary.totalFailed > 0 ? "yellow" : "green"}>
            {state.summary.sites} site(s), {state.summary.totalSteps} step(s),{" "}
            {state.summary.totalFailed} failed
          </Text>
          <Text dimColor>output: {OUTPUT_DIR}/{runId}</Text>
          <Text dimColor>press q to return to dashboard</Text>
        </Box>
      ) : (
        <Text dimColor>running…</Text>
      )}
    </Box>
  );
}
