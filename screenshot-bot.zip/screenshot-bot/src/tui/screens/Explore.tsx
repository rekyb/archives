import { useState } from "react";
import { Box, Text, useInput } from "ink";
import TextInput from "ink-text-input";
import { useApp } from "ink";
import { setPendingCommand } from "../pending";
import type { ScreenProps } from "./types";

type Field = "url" | "name" | "instruction" | "profile";

/**
 * "Full LLM mode": prompt for a base URL (required), an optional recipe name,
 * an optional custom instruction, and a Chrome-profile toggle, then enqueue
 * `explore <url> [name] [--instruction …] [--profile]` via the same suspend->
 * child->relaunch pattern used for login/inspect/author/repair.
 *
 * The profile toggle is its own focusable step (not a global `p` handler) so
 * typing the letter "p" into the URL/name/instruction TextInputs never flips
 * it — `p` is only consumed once focus has left every text field.
 */
export function Explore({ goHome }: ScreenProps) {
  const { exit } = useApp();
  const [field, setField] = useState<Field>("url");
  const [url, setUrl] = useState("");
  const [name, setName] = useState("");
  const [instruction, setInstruction] = useState("");
  const [profile, setProfile] = useState(false);

  const submit = () => {
    const trimmedUrl = url.trim();
    if (trimmedUrl.length === 0) return;
    const trimmedName = name.trim();
    const trimmedInstruction = instruction.trim();
    setPendingCommand({
      label: `explore ${trimmedUrl}`,
      command: "npx",
      args: [
        "tsx",
        "src/cli.ts",
        "explore",
        trimmedUrl,
        ...(trimmedName ? [trimmedName] : []),
        ...(trimmedInstruction ? ["--instruction", trimmedInstruction] : []),
        ...(profile ? ["--profile"] : []),
      ],
    });
    exit();
  };

  const submitUrl = () => {
    if (url.trim().length === 0) return;
    setField("name");
  };

  // Only active on the profile step (no TextInput focused), so `p` is safe.
  useInput(
    (input, key) => {
      if (input === "p") setProfile((v) => !v);
      if (key.return) submit();
    },
    { isActive: field === "profile" },
  );

  return (
    <Box flexDirection="column">
      <Text bold color="cyan">
        Explore (LLM)
      </Text>
      <Text dimColor>
        The LLM navigates the site with no recipe, writes one, then captures. q back
      </Text>
      <Box marginTop={1}>
        <Text>{field === "url" ? "❯ " : "  "}base URL: </Text>
        <TextInput
          value={url}
          onChange={setUrl}
          onSubmit={submitUrl}
          focus={field === "url"}
          placeholder="example.com"
        />
      </Box>
      <Box>
        <Text>{field === "name" ? "❯ " : "  "}name (optional): </Text>
        <TextInput
          value={name}
          onChange={setName}
          onSubmit={() => setField("instruction")}
          focus={field === "name"}
          placeholder="(derived from URL)"
        />
      </Box>
      <Box>
        <Text>{field === "instruction" ? "❯ " : "  "}instruction (optional): </Text>
        <TextInput
          value={instruction}
          onChange={setInstruction}
          onSubmit={() => setField("profile")}
          focus={field === "instruction"}
          placeholder="e.g. capture the pricing and checkout pages"
        />
      </Box>
      <Text color={field === "profile" ? "cyan" : undefined}>
        {field === "profile" ? "❯ " : "  "}
        {profile ? "[x]" : "[ ]"} Use my Chrome profile (no login){" "}
        <Text dimColor>[p]</Text>
      </Text>
      {profile ? (
        <Text color="yellow">
          Chrome must be closed while running (a profile can&apos;t be used by two
          Chrome processes).
        </Text>
      ) : null}
      <Text dimColor>
        enter advances between fields; enter on the profile step starts exploration
      </Text>
    </Box>
  );
}
