import { useEffect, useState } from "react";
import { Box, Text, useApp, useInput } from "ink";
import { listRecipeNames, loadRecipeByName } from "../../core/recipes-dir";
import { sessionInfo } from "../../core/session";
import { RECIPES_DIR, SESSIONS_DIR } from "../../core/paths";
import { setPendingCommand } from "../pending";
import { relativeAge } from "../format";
import type { ScreenProps } from "./types";

interface Row {
  recipe: string;
  sessionName: string;
  exists: boolean;
  mtime?: Date;
}

export function Sessions({ goHome }: ScreenProps) {
  const { exit } = useApp();
  const [rows, setRows] = useState<Row[]>([]);
  const [cursor, setCursor] = useState(0);

  useEffect(() => {
    (async () => {
      const names = await listRecipeNames(RECIPES_DIR);
      const built: Row[] = [];
      for (const recipe of names) {
        let sessionName = recipe;
        try {
          const r = await loadRecipeByName(RECIPES_DIR, recipe);
          sessionName = r.session ?? r.name;
        } catch {
          /* fall back to recipe name */
        }
        const info = await sessionInfo(SESSIONS_DIR, sessionName);
        built.push({ recipe, sessionName, exists: info.exists, mtime: info.mtime });
      }
      setRows(built);
    })().catch(() => setRows([]));
  }, []);

  useInput((input, key) => {
    if (key.upArrow || input === "k") setCursor((c) => Math.max(0, c - 1));
    if (key.downArrow || input === "j")
      setCursor((c) => Math.min(rows.length - 1, c + 1));
    // 'l' = login: suspend the TUI and run the interactive login child process.
    if (input === "l" && rows[cursor]) {
      setPendingCommand({
        label: `login ${rows[cursor].recipe}`,
        command: "npx",
        args: ["tsx", "src/cli.ts", "login", rows[cursor].recipe],
      });
      exit();
    }
    // 'i' = inspect the selected recipe interactively.
    if (input === "i" && rows[cursor]) {
      setPendingCommand({
        label: `inspect ${rows[cursor].recipe}`,
        command: "npx",
        args: ["tsx", "src/cli.ts", "inspect", rows[cursor].recipe],
      });
      exit();
    }
  });

  return (
    <Box flexDirection="column">
      <Text bold color="cyan">
        Sessions
      </Text>
      <Text dimColor>l login · i inspect · ↑↓ move · q back</Text>
      <Box flexDirection="column" marginTop={1}>
        {rows.length === 0 ? (
          <Text dimColor>(no recipes)</Text>
        ) : (
          rows.map((r, i) => (
            <Text key={r.recipe} color={i === cursor ? "cyan" : undefined}>
              {i === cursor ? "❯ " : "  "}
              {r.recipe}{" "}
              {r.exists ? (
                <Text color="green">
                  ✓ {r.mtime ? relativeAge(r.mtime) : "saved"}
                </Text>
              ) : (
                <Text color="gray">— no session</Text>
              )}
            </Text>
          ))
        )}
      </Box>
    </Box>
  );
}
