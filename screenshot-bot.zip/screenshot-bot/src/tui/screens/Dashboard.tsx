import { Box, Text, useApp } from "ink";
import SelectInput from "ink-select-input";
import type { Screen } from "./types";

export interface DashboardProps {
  onNavigate: (screen: Screen) => void;
  /** Whether the optional LLM is configured — gates the Explore item. */
  llmAvailable?: boolean;
}

interface Item {
  label: string;
  value: Screen | "quit";
}

export function Dashboard({ onNavigate, llmAvailable = false }: DashboardProps) {
  const { exit } = useApp();

  const items: Item[] = [
    { label: "Run a crawl", value: "run" },
    ...(llmAvailable
      ? [{ label: "Explore (LLM)", value: "explore" as const }]
      : []),
    { label: "Sessions (logins)", value: "sessions" },
    { label: "Recipes", value: "recipes" },
    { label: "Output (screenshots)", value: "output" },
    { label: "Quit", value: "quit" },
  ];

  const handleSelect = (item: Item) => {
    if (item.value === "quit") {
      exit();
      return;
    }
    onNavigate(item.value);
  };

  return (
    <Box flexDirection="column">
      <Text bold color="cyan">
        screenshot-bot control center
      </Text>
      <Text dimColor>Select a screen (↑↓ + enter). Press q to quit.</Text>
      <Box marginTop={1}>
        <SelectInput items={items} onSelect={handleSelect} />
      </Box>
      {llmAvailable ? null : (
        <Text dimColor>
          Full LLM mode hidden — set a provider token (e.g. ANTHROPIC_API_KEY) to
          enable site exploration.
        </Text>
      )}
    </Box>
  );
}
