import { useEffect, useState } from "react";
import { readdir, stat, open } from "node:fs/promises";
import { join } from "node:path";
import { Box, Text, useInput } from "ink";
import { OUTPUT_DIR } from "../../core/paths";
import { humanBytes } from "../format";
import type { ScreenProps } from "./types";

type Level = "runs" | "sites" | "shots";

interface Shot {
  file: string;
  path: string;
  bytes: number;
  dims?: string;
}

/** Newest-first list of immediate subdirectory names. */
async function listDirsNewestFirst(dir: string): Promise<string[]> {
  let entries: string[];
  try {
    entries = await readdir(dir);
  } catch {
    return [];
  }
  const withTime: { name: string; mtime: number }[] = [];
  for (const name of entries) {
    try {
      const s = await stat(join(dir, name));
      if (s.isDirectory()) withTime.push({ name, mtime: s.mtimeMs });
    } catch {
      /* ignore */
    }
  }
  return withTime.sort((a, b) => b.mtime - a.mtime).map((e) => e.name);
}

/** Best-effort PNG dimensions from the IHDR chunk (bytes 16..24). */
async function pngDims(path: string): Promise<string | undefined> {
  try {
    const fh = await open(path, "r");
    try {
      const buf = Buffer.alloc(24);
      const { bytesRead } = await fh.read(buf, 0, 24, 0);
      if (bytesRead >= 24 && buf.toString("ascii", 1, 4) === "PNG") {
        const w = buf.readUInt32BE(16);
        const h = buf.readUInt32BE(20);
        return `${w}x${h}`;
      }
    } finally {
      await fh.close();
    }
  } catch {
    /* best-effort */
  }
  return undefined;
}

export function Output({ goHome }: ScreenProps) {
  const [level, setLevel] = useState<Level>("runs");
  const [runs, setRuns] = useState<string[]>([]);
  const [sites, setSites] = useState<string[]>([]);
  const [shots, setShots] = useState<Shot[]>([]);
  const [run, setRun] = useState("");
  const [site, setSite] = useState("");
  const [cursor, setCursor] = useState(0);

  useEffect(() => {
    listDirsNewestFirst(OUTPUT_DIR).then(setRuns).catch(() => setRuns([]));
  }, []);

  const openRun = async (name: string) => {
    setRun(name);
    setCursor(0);
    setSites(await listDirsNewestFirst(join(OUTPUT_DIR, name)));
    setLevel("sites");
  };

  const openSite = async (name: string) => {
    setSite(name);
    setCursor(0);
    const dir = join(OUTPUT_DIR, run, name);
    let files: string[] = [];
    try {
      files = (await readdir(dir)).filter((f) => f.endsWith(".png")).sort();
    } catch {
      files = [];
    }
    const built: Shot[] = [];
    for (const file of files) {
      const path = join(dir, file);
      let bytes = 0;
      try {
        bytes = (await stat(path)).size;
      } catch {
        /* ignore */
      }
      built.push({ file, path, bytes, dims: await pngDims(path) });
    }
    setShots(built);
    setLevel("shots");
  };

  const count =
    level === "runs" ? runs.length : level === "sites" ? sites.length : shots.length;

  useInput((input, key) => {
    if (key.upArrow || input === "k") setCursor((c) => Math.max(0, c - 1));
    if (key.downArrow || input === "j") setCursor((c) => Math.min(count - 1, c + 1));
    if (key.leftArrow || input === "h") {
      if (level === "shots") {
        setLevel("sites");
        setCursor(0);
      } else if (level === "sites") {
        setLevel("runs");
        setCursor(0);
      }
    }
    if (key.return || key.rightArrow || input === "l") {
      if (level === "runs" && runs[cursor]) void openRun(runs[cursor]);
      else if (level === "sites" && sites[cursor]) void openSite(sites[cursor]);
    }
  });

  return (
    <Box flexDirection="column">
      <Text bold color="cyan">
        Output {level !== "runs" ? `· ${run}` : ""}
        {level === "shots" ? ` · ${site}` : ""}
      </Text>
      <Text dimColor>enter/→ open · ←/h back a level · q dashboard</Text>
      <Box flexDirection="column" marginTop={1}>
        {level === "runs" &&
          (runs.length === 0 ? (
            <Text dimColor>(no runs in {OUTPUT_DIR})</Text>
          ) : (
            runs.map((r, i) => (
              <Text key={r} color={i === cursor ? "cyan" : undefined}>
                {i === cursor ? "❯ " : "  "}
                {r}
              </Text>
            ))
          ))}
        {level === "sites" &&
          (sites.length === 0 ? (
            <Text dimColor>(no sites in this run)</Text>
          ) : (
            sites.map((s, i) => (
              <Text key={s} color={i === cursor ? "cyan" : undefined}>
                {i === cursor ? "❯ " : "  "}
                {s}
              </Text>
            ))
          ))}
        {level === "shots" &&
          (shots.length === 0 ? (
            <Text dimColor>(no screenshots)</Text>
          ) : (
            shots.map((s, i) => (
              <Box key={s.file} flexDirection="column">
                <Text color={i === cursor ? "cyan" : undefined}>
                  {i === cursor ? "❯ " : "  "}
                  <Text bold>{s.file}</Text> <Text dimColor>{humanBytes(s.bytes)}</Text>
                  {s.dims ? <Text dimColor> · {s.dims}</Text> : null}
                </Text>
                <Text dimColor>    {s.path}</Text>
              </Box>
            ))
          ))}
      </Box>
    </Box>
  );
}
