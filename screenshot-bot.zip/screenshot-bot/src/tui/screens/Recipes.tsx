import { useEffect, useState } from "react";
import { Box, Text, useApp, useInput } from "ink";
import { listRecipeNames, loadRecipeByName } from "../../core/recipes-dir";
import { RECIPES_DIR } from "../../core/paths";
import { loadLlmStatus, type LlmStatus } from "../llm";
import { setPendingCommand } from "../pending";
import type { ScreenProps } from "./types";

interface Row {
  name: string;
  ok: boolean;
  message: string;
}

export function Recipes({ goHome }: ScreenProps) {
  const { exit } = useApp();
  const [rows, setRows] = useState<Row[]>([]);
  const [cursor, setCursor] = useState(0);
  const [llm, setLlm] = useState<LlmStatus | null>(null);

  useEffect(() => {
    loadLlmStatus().then(setLlm).catch(() => setLlm({ available: false }));
    (async () => {
      const names = await listRecipeNames(RECIPES_DIR);
      const built: Row[] = [];
      for (const name of names) {
        try {
          const r = await loadRecipeByName(RECIPES_DIR, name);
          built.push({ name, ok: true, message: `${r.steps.length} steps · ${r.baseUrl}` });
        } catch (err) {
          built.push({
            name,
            ok: false,
            message: err instanceof Error ? err.message : String(err),
          });
        }
      }
      setRows(built);
    })().catch(() => setRows([]));
  }, []);

  useInput((input, key) => {
    if (key.upArrow || input === "k") setCursor((c) => Math.max(0, c - 1));
    if (key.downArrow || input === "j")
      setCursor((c) => Math.min(rows.length - 1, c + 1));
    if (!llm?.available) return;
    // 'n' = author a NEW recipe (interactive LLM child); 'r' = repair selected.
    if (input === "n") {
      setPendingCommand({
        label: "author new recipe",
        command: "npx",
        args: ["tsx", "src/cli.ts", "author", "new-recipe"],
      });
      exit();
    }
    if (input === "r" && rows[cursor]) {
      setPendingCommand({
        label: `repair ${rows[cursor].name}`,
        command: "npx",
        args: ["tsx", "src/cli.ts", "repair", rows[cursor].name],
      });
      exit();
    }
  });

  return (
    <Box flexDirection="column">
      <Text bold color="cyan">
        Recipes
      </Text>
      {llm?.available ? (
        <Text dimColor>n author new · r repair selected · ↑↓ move · q back</Text>
      ) : (
        <Text dimColor>
          LLM off — Claude Code can author/repair recipes instead · ↑↓ move · q back
        </Text>
      )}
      <Box flexDirection="column" marginTop={1}>
        {rows.length === 0 ? (
          <Text dimColor>(no recipes in {RECIPES_DIR})</Text>
        ) : (
          rows.map((r, i) => (
            <Box key={r.name}>
              <Text color={i === cursor ? "cyan" : undefined}>
                {i === cursor ? "❯ " : "  "}
                {r.ok ? <Text color="green">ok </Text> : <Text color="red">err</Text>}{" "}
                <Text bold>{r.name}</Text> <Text dimColor>{r.message}</Text>
              </Text>
            </Box>
          ))
        )}
      </Box>
    </Box>
  );
}
