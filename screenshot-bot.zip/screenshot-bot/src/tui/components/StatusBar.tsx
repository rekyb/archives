import { Box, Text } from "ink";
import type { LlmStatus } from "../llm";

export interface StatusBarProps {
  recipes: number;
  sessions: number;
  llm: LlmStatus | null;
}

function llmLabel(llm: LlmStatus | null): string {
  if (!llm) return "…";
  if (!llm.available) return "off";
  const parts = [llm.provider, llm.model].filter(Boolean);
  return parts.length > 0 ? parts.join("/") : "on";
}

export function StatusBar({ recipes, sessions, llm }: StatusBarProps) {
  return (
    <Box borderStyle="single" borderColor="gray" paddingX={1}>
      <Text>
        <Text color="cyan">recipes</Text> {recipes} {"  "}
        <Text color="cyan">sessions</Text> {sessions} {"  "}
        <Text color="cyan">llm</Text>{" "}
        <Text color={llm?.available ? "green" : "gray"}>{llmLabel(llm)}</Text>
      </Text>
    </Box>
  );
}
