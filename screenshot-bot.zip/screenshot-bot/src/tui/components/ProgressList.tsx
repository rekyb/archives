import { Box, Text } from "ink";
import Spinner from "ink-spinner";
import type { SiteProgress } from "../run-state";

export interface ProgressListProps {
  sites: SiteProgress[];
}

/** Per-site progress: step X/N, running spinner, ok/failed tallies. */
export function ProgressList({ sites }: ProgressListProps) {
  if (sites.length === 0) {
    return <Text dimColor>(waiting for run to start…)</Text>;
  }
  return (
    <Box flexDirection="column">
      {sites.map((s) => (
        <Box key={s.site}>
          <Box marginRight={1}>
            {s.done ? (
              <Text color={s.failed > 0 ? "yellow" : "green"}>
                {s.failed > 0 ? "✗" : "✓"}
              </Text>
            ) : (
              <Text color="cyan">
                <Spinner type="dots" />
              </Text>
            )}
          </Box>
          <Text>
            <Text bold>{s.site}</Text>{" "}
            <Text dimColor>
              step {Math.min(s.current, s.stepCount) || 0}/{s.stepCount}
            </Text>{" "}
            <Text color="green">{s.ok}✓</Text>{" "}
            <Text color={s.failed > 0 ? "red" : "gray"}>{s.failed}✗</Text>
            {!s.done && s.currentLabel ? <Text dimColor> — {s.currentLabel}</Text> : null}
          </Text>
        </Box>
      ))}
    </Box>
  );
}
