import { Box, Text } from "ink";

export interface LogViewProps {
  lines: string[];
  /** How many trailing lines to show. */
  max?: number;
  title?: string;
}

/** Renders the last `max` lines of a scrolling log. */
export function LogView({ lines, max = 12, title = "log" }: LogViewProps) {
  const shown = lines.slice(-max);
  return (
    <Box flexDirection="column" borderStyle="round" borderColor="gray" paddingX={1}>
      <Text dimColor>{title}</Text>
      {shown.length === 0 ? (
        <Text dimColor>(no output yet)</Text>
      ) : (
        shown.map((line, i) => (
          <Text key={`${i}-${line}`} wrap="truncate-end">
            {line}
          </Text>
        ))
      )}
    </Box>
  );
}
