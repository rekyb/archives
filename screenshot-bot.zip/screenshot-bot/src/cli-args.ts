export interface ExtractedOption {
  value?: string;
  rest: string[];
}

/**
 * Pull an option (e.g. `--instruction "…"` or `--instruction=…`, plus aliases
 * like `-i`) out of an argv-style list, returning its value and the remaining
 * positional args. First occurrence wins; unmatched args pass through.
 */
export function extractOption(args: string[], names: string[]): ExtractedOption {
  const rest: string[] = [];
  let value: string | undefined;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (value !== undefined) {
      rest.push(arg);
      continue;
    }

    const eq = names.find((n) => arg.startsWith(`${n}=`));
    if (eq) {
      value = arg.slice(eq.length + 1);
      continue;
    }
    if (names.includes(arg)) {
      value = args[i + 1] ?? "";
      i += 1; // consume the value
      continue;
    }
    rest.push(arg);
  }

  return value !== undefined ? { value, rest } : { rest };
}

export interface FlagResult {
  present: boolean;
  rest: string[];
}

/** Pull a boolean flag (e.g. `--profile`) out of an argv-style list. */
export function takeFlag(args: string[], names: string[]): FlagResult {
  let present = false;
  const rest = args.filter((a) => {
    if (names.includes(a)) {
      present = true;
      return false;
    }
    return true;
  });
  return { present, rest };
}
