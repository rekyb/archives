import { afterEach, beforeEach, describe, expect, test } from "vitest";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createLogger } from "../src/core/logger";
import type { RunEvent } from "../src/core/events";

let dir: string;

beforeEach(async () => {
  dir = await mkdtemp(join(tmpdir(), "sb-log-"));
});
afterEach(async () => {
  await rm(dir, { recursive: true, force: true });
});

const events: RunEvent[] = [
  { type: "runStart", runId: "R1", sites: ["acme"] },
  { type: "siteStart", site: "acme", outDir: `${"/x"}`, stepCount: 2 },
  { type: "stepStart", site: "acme", index: 0, label: "goto /home" },
  { type: "stepDone", site: "acme", index: 0, label: "goto /home", durationMs: 12 },
  {
    type: "stepFailed",
    site: "acme",
    index: 1,
    label: "click #missing",
    error: "selector not found",
    screenshot: "shot-FAILED.png",
  },
  { type: "siteEnd", site: "acme", ok: 1, failed: 1 },
  { type: "runEnd", summary: { sites: 1, totalSteps: 2, totalFailed: 1 } },
];

describe("createLogger", () => {
  test("writes one JSON line per event to run.jsonl", async () => {
    const logger = await createLogger(dir);
    for (const e of events) await logger.log(e);
    await logger.close();

    const jsonl = await readFile(join(dir, "run.jsonl"), "utf8");
    const lines = jsonl.trim().split("\n");
    expect(lines).toHaveLength(events.length);
    const parsed = lines.map((l) => JSON.parse(l));
    expect(parsed[0]).toMatchObject({ type: "runStart", runId: "R1" });
    expect(parsed.every((p) => typeof p.at === "string")).toBe(true);
  });

  test("writes a human-readable run.log that records failures", async () => {
    const logger = await createLogger(dir);
    for (const e of events) await logger.log(e);
    await logger.close();

    const log = await readFile(join(dir, "run.log"), "utf8");
    expect(log).toContain("goto /home");
    expect(log).toMatch(/FAIL|failed/i);
    expect(log).toContain("selector not found");
  });
});
