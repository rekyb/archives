import { afterEach, beforeEach, describe, expect, test } from "vitest";
import { mkdtemp, rm, stat } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { runRecipes } from "../src/core/runner";
import type { RunEvent } from "../src/core/events";
import type { Recipe } from "../src/core/recipe";

process.env.SCREENSHOT_BOT_NO_SANDBOX = "1";

const fixture = pathToFileURL(
  join(fileURLToPath(new URL(".", import.meta.url)), "fixtures", "page.html"),
).href;

let out: string;
let profile: string;
beforeEach(async () => {
  out = await mkdtemp(join(tmpdir(), "sb-prof-out-"));
  profile = await mkdtemp(join(tmpdir(), "sb-prof-dir-"));
});
afterEach(async () => {
  await rm(out, { recursive: true, force: true });
  await rm(profile, { recursive: true, force: true });
});

const recipe: Recipe = {
  name: "fixture",
  baseUrl: fixture,
  session: "should-be-ignored-in-profile-mode",
  viewport: { width: 800, height: 600 },
  steps: [
    { type: "goto", url: fixture },
    { type: "waitFor", target: "text=Welcome" },
    { type: "screenshot", name: "home" },
  ],
};

describe("runRecipes with a Chrome profile (persistent context)", () => {
  test(
    "runs against a persistent-context profile dir and captures screenshots",
    { timeout: 60_000 },
    async () => {
      const events: RunEvent[] = [];
      for await (const e of runRecipes([recipe], {
        runId: "R1",
        outputRoot: out,
        sessionsDir: join(out, "sessions"),
        headless: true,
        profileDir: profile,
      })) {
        events.push(e);
      }

      expect(events.filter((e) => e.type === "stepFailed")).toHaveLength(0);
      const shot = await stat(join(out, "R1", "fixture", "home.png"));
      expect(shot.size).toBeGreaterThan(0);
    },
  );
});
