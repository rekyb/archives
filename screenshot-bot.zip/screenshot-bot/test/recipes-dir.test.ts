import { afterEach, beforeEach, describe, expect, test } from "vitest";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { listRecipeNames, loadRecipeByName, loadRecipes } from "../src/core/recipes-dir";
import { makeRunId } from "../src/core/paths";

let dir: string;
const YAML = (name: string) => `name: ${name}\nbaseUrl: https://x.test\nsteps:\n  - screenshot: home\n`;

beforeEach(async () => {
  dir = await mkdtemp(join(tmpdir(), "sb-rd-"));
});
afterEach(async () => {
  await rm(dir, { recursive: true, force: true });
});

describe("recipes-dir", () => {
  test("lists .yaml/.yml stems sorted, ignoring other files", async () => {
    await writeFile(join(dir, "b.yaml"), YAML("b"));
    await writeFile(join(dir, "a.yml"), YAML("a"));
    await writeFile(join(dir, "notes.txt"), "nope");
    expect(await listRecipeNames(dir)).toEqual(["a", "b"]);
  });

  test("listRecipeNames returns [] for a missing dir", async () => {
    expect(await listRecipeNames(join(dir, "nope"))).toEqual([]);
  });

  test("loadRecipeByName loads and parses", async () => {
    await writeFile(join(dir, "a.yaml"), YAML("a"));
    expect((await loadRecipeByName(dir, "a")).name).toBe("a");
  });

  test("loadRecipeByName throws a clear error when missing", async () => {
    await expect(loadRecipeByName(dir, "ghost")).rejects.toThrow(/ghost.*not found/i);
  });

  test("loadRecipes with empty names loads all", async () => {
    await writeFile(join(dir, "a.yaml"), YAML("a"));
    await writeFile(join(dir, "b.yaml"), YAML("b"));
    expect((await loadRecipes(dir, [])).map((r) => r.name)).toEqual(["a", "b"]);
  });
});

describe("makeRunId", () => {
  test("formats YYYYMMDD-HHMMSS", () => {
    expect(makeRunId(new Date(2026, 6, 2, 14, 30, 5))).toBe("20260702-143005");
  });
});
