import { afterEach, describe, expect, test, vi } from "vitest";
import { homedir } from "node:os";
import { join } from "node:path";
import { defaultChromeUserDataDir, resolveProfileDir } from "../src/core/profile";

afterEach(() => vi.unstubAllEnvs());

describe("defaultChromeUserDataDir", () => {
  test("linux path", () => {
    expect(defaultChromeUserDataDir("linux")).toBe(join(homedir(), ".config", "google-chrome"));
  });
  test("darwin path", () => {
    expect(defaultChromeUserDataDir("darwin")).toBe(
      join(homedir(), "Library", "Application Support", "Google", "Chrome"),
    );
  });
});

describe("resolveProfileDir", () => {
  test("prefers the explicit arg", () => {
    vi.stubEnv("SCREENSHOT_BOT_BROWSER_PROFILE", "/from/env");
    expect(resolveProfileDir("/explicit")).toBe("/explicit");
  });
  test("falls back to the env var", () => {
    vi.stubEnv("SCREENSHOT_BOT_BROWSER_PROFILE", "/from/env");
    expect(resolveProfileDir()).toBe("/from/env");
  });
  test("falls back to the OS default", () => {
    vi.stubEnv("SCREENSHOT_BOT_BROWSER_PROFILE", undefined as unknown as string);
    expect(resolveProfileDir()).toBe(defaultChromeUserDataDir());
  });
});
