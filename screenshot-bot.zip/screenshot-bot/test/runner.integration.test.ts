import { afterEach, beforeEach, describe, expect, test } from "vitest";
import { mkdtemp, rm, stat } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { runRecipes } from "../src/core/runner";
import type { RunEvent } from "../src/core/events";
import type { Recipe } from "../src/core/recipe";

process.env.SCREENSHOT_BOT_NO_SANDBOX = "1";

const fixture = pathToFileURL(
  join(fileURLToPath(new URL(".", import.meta.url)), "fixtures", "page.html"),
).href;

let out: string;
beforeEach(async () => {
  out = await mkdtemp(join(tmpdir(), "sb-run-"));
});
afterEach(async () => {
  await rm(out, { recursive: true, force: true });
});

const recipe: Recipe = {
  name: "fixture",
  baseUrl: fixture,
  viewport: { width: 800, height: 600 },
  steps: [
    { type: "goto", url: fixture },
    { type: "waitFor", target: "text=Welcome" },
    { type: "screenshot", name: "home" },
    { type: "click", selector: "#present" },
    { type: "click", selector: "#does-not-exist" }, // fails
    { type: "scroll", target: "bottom" },
    { type: "screenshot", name: "bottom" },
  ],
};

describe("runRecipes (integration)", () => {
  test("captures screenshots, logs failures, and continues", { timeout: 60_000 }, async () => {
    const events: RunEvent[] = [];
    for await (const e of runRecipes([recipe], {
      runId: "R1",
      outputRoot: out,
      sessionsDir: join(out, "sessions"),
      headless: true,
    })) {
      events.push(e);
    }

    const types = events.map((e) => e.type);
    expect(types[0]).toBe("runStart");
    expect(types.at(-1)).toBe("runEnd");
    expect(types).toContain("siteStart");
    expect(types).toContain("siteEnd");

    // The bad click failed; everything else succeeded and the run continued.
    const failed = events.filter((e) => e.type === "stepFailed");
    expect(failed).toHaveLength(1);
    expect(failed[0]).toMatchObject({ label: "click #does-not-exist" });

    const runEnd = events.at(-1);
    expect(runEnd).toMatchObject({ type: "runEnd" });
    if (runEnd?.type === "runEnd") {
      expect(runEnd.summary.totalFailed).toBe(1);
      expect(runEnd.summary.sites).toBe(1);
    }

    // Screenshots exist, including a full-page capture and the FAILED shot.
    const siteDir = join(out, "R1", "fixture");
    const home = await stat(join(siteDir, "home.png"));
    expect(home.size).toBeGreaterThan(0);
    await expect(stat(join(siteDir, "bottom.png"))).resolves.toBeTruthy();
    await expect(stat(join(siteDir, "step-5-FAILED.png"))).resolves.toBeTruthy();
  });
});
