import { afterEach, beforeEach, describe, expect, test } from "vitest";
import { mkdtemp, rm, stat } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { MockLanguageModelV1 } from "ai/test";
import { exploreAndCapture } from "../src/llm/explore";

process.env.SCREENSHOT_BOT_NO_SANDBOX = "1";

const fixture = pathToFileURL(
  join(fileURLToPath(new URL(".", import.meta.url)), "fixtures", "page.html"),
).href;

function toolCall(id: string, toolName: string, args: unknown) {
  return {
    finishReason: "tool-calls" as const,
    usage: { promptTokens: 1, completionTokens: 1 },
    rawCall: { rawPrompt: null, rawSettings: {} },
    toolCalls: [
      { toolCallType: "function" as const, toolCallId: id, toolName, args: JSON.stringify(args) },
    ],
  };
}

let dir: string;
beforeEach(async () => {
  dir = await mkdtemp(join(tmpdir(), "sb-explore-"));
});
afterEach(async () => {
  await rm(dir, { recursive: true, force: true });
});

describe("exploreAndCapture (full LLM mode)", () => {
  test(
    "explores, writes a recipe, and captures screenshots to output",
    { timeout: 90_000 },
    async () => {
      const responses = [
        toolCall("c1", "capture", { name: "home" }),
        toolCall("c2", "finish", {}),
      ];
      let i = 0;
      const model = new MockLanguageModelV1({
        doGenerate: async () => responses[Math.min(i++, responses.length - 1)],
      });

      const { recipePath, recipe } = await exploreAndCapture({
        name: "fixture",
        baseUrl: fixture,
        recipesDir: dir,
        sessionsDir: join(dir, "sessions"),
        outputRoot: join(dir, "output"),
        runId: "R1",
        headless: true,
        model,
        maxModelSteps: 4,
      });

      // A recipe was authored (goto + screenshot) and written to disk.
      expect(recipe.steps.map((s) => s.type)).toEqual(["goto", "screenshot"]);
      await expect(stat(recipePath)).resolves.toBeTruthy();

      // Replaying it captured a real screenshot under output/<runId>/<name>/.
      const shot = await stat(join(dir, "output", "R1", "fixture", "home.png"));
      expect(shot.size).toBeGreaterThan(0);
    },
  );
});
