import { describe, it, expect } from "vitest";
import { render } from "ink-testing-library";
import { Dashboard } from "../src/tui/screens/Dashboard";
import { Explore } from "../src/tui/screens/Explore";
import { RunScreen } from "../src/tui/screens/RunScreen";
import { ProgressList } from "../src/tui/components/ProgressList";
import { LogView } from "../src/tui/components/LogView";
import { initialRunState, runReducer, type RunViewState } from "../src/tui/run-state";
import type { RunEvent } from "../src/core/events";

/** Apply a scripted list of events through the pure reducer. */
function reduceAll(events: RunEvent[]): RunViewState {
  return events.reduce(runReducer, initialRunState);
}

const SCRIPT: RunEvent[] = [
  { type: "runStart", runId: "20260702-120000", sites: ["alpha", "beta"] },
  { type: "siteStart", site: "alpha", outDir: "/out/alpha", stepCount: 2 },
  { type: "stepStart", site: "alpha", index: 0, label: "goto /" },
  { type: "stepDone", site: "alpha", index: 0, label: "goto /", durationMs: 42 },
  { type: "stepStart", site: "alpha", index: 1, label: "screenshot home" },
  {
    type: "stepFailed",
    site: "alpha",
    index: 1,
    label: "screenshot home",
    error: "boom",
    screenshot: "step-2-FAILED.png",
  },
  { type: "siteEnd", site: "alpha", ok: 1, failed: 1 },
  { type: "runEnd", summary: { sites: 1, totalSteps: 2, totalFailed: 1 } },
];

describe("Dashboard", () => {
  it("renders all menu options", () => {
    const { lastFrame } = render(<Dashboard onNavigate={() => {}} />);
    const frame = lastFrame() ?? "";
    expect(frame).toContain("Run a crawl");
    expect(frame).toContain("Sessions");
    expect(frame).toContain("Recipes");
    expect(frame).toContain("Output");
    expect(frame).toContain("Quit");
  });

  it("hides Explore (LLM) when the LLM is unavailable", () => {
    const { lastFrame } = render(
      <Dashboard onNavigate={() => {}} llmAvailable={false} />,
    );
    const frame = lastFrame() ?? "";
    expect(frame).not.toContain("Explore (LLM)");
    expect(frame).toContain("set a provider token");
  });

  it("shows Explore (LLM) when the LLM is available", () => {
    const { lastFrame } = render(
      <Dashboard onNavigate={() => {}} llmAvailable={true} />,
    );
    const frame = lastFrame() ?? "";
    expect(frame).toContain("Explore (LLM)");
  });
});

describe("Explore", () => {
  it("prompts for base URL, name, instruction, and a Chrome-profile toggle", () => {
    const { lastFrame } = render(<Explore goHome={() => {}} />);
    const frame = lastFrame() ?? "";
    expect(frame).toContain("base URL");
    expect(frame).toContain("name (optional)");
    expect(frame).toContain("instruction (optional)");
    expect(frame).toContain("Use my Chrome profile (no login)");
  });
});

describe("RunScreen", () => {
  it("offers a 'use my Chrome profile' toggle in the selection step", () => {
    const { lastFrame } = render(<RunScreen goHome={() => {}} />);
    const frame = lastFrame() ?? "";
    expect(frame).toContain("Use my Chrome profile (no login)");
  });
});

describe("runReducer", () => {
  it("tracks per-site progress and the final summary", () => {
    const state = reduceAll(SCRIPT);
    expect(state.runId).toBe("20260702-120000");
    expect(state.sites).toHaveLength(1);
    const alpha = state.sites[0];
    expect(alpha.site).toBe("alpha");
    expect(alpha.stepCount).toBe(2);
    expect(alpha.ok).toBe(1);
    expect(alpha.failed).toBe(1);
    expect(alpha.done).toBe(true);
    expect(state.done).toBe(true);
    expect(state.summary).toEqual({ sites: 1, totalSteps: 2, totalFailed: 1 });
    // log captured both a success and a failure line
    expect(state.log.some((l) => l.includes("✓ goto /"))).toBe(true);
    expect(state.log.some((l) => l.includes("✗ screenshot home"))).toBe(true);
  });

  it("starts empty", () => {
    expect(initialRunState.sites).toHaveLength(0);
    expect(initialRunState.done).toBe(false);
  });
});

describe("ProgressList / LogView", () => {
  it("shows step tallies from reduced state", () => {
    const state = reduceAll(SCRIPT);
    const { lastFrame } = render(<ProgressList sites={state.sites} />);
    const frame = lastFrame() ?? "";
    expect(frame).toContain("alpha");
    expect(frame).toContain("2/2");
    expect(frame).toContain("1✓");
    expect(frame).toContain("1✗");
  });

  it("renders the last N log lines and the summary line", () => {
    const state = reduceAll(SCRIPT);
    const { lastFrame } = render(<LogView lines={state.log} max={12} />);
    const frame = lastFrame() ?? "";
    expect(frame).toContain("done — 1 site(s), 2 step(s), 1 failed");
  });
});
