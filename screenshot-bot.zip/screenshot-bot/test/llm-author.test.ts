import { afterEach, beforeEach, describe, expect, test } from "vitest";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { MockLanguageModelV1 } from "ai/test";
import { loadRecipe } from "../src/core/recipe";
import { authorRecipe } from "../src/llm/author";
import { normalizeRawStep } from "../src/llm/recipe-build";

process.env.SCREENSHOT_BOT_NO_SANDBOX = "1";

const fixture = pathToFileURL(
  join(fileURLToPath(new URL(".", import.meta.url)), "fixtures", "page.html"),
).href;

let dir: string;
beforeEach(async () => {
  dir = await mkdtemp(join(tmpdir(), "sb-llm-"));
});
afterEach(async () => {
  await rm(dir, { recursive: true, force: true });
});

/** Build a doGenerate result that emits a single tool call. */
function toolCall(id: string, toolName: string, args: unknown) {
  return {
    finishReason: "tool-calls" as const,
    usage: { promptTokens: 1, completionTokens: 1 },
    rawCall: { rawPrompt: null, rawSettings: {} },
    toolCalls: [
      { toolCallType: "function" as const, toolCallId: id, toolName, args: JSON.stringify(args) },
    ],
  };
}

describe("recipe-build helpers", () => {
  test("normalizeRawStep validates and normalizes step forms", () => {
    expect(normalizeRawStep({ type: "click", selector: "#a" })).toEqual({
      type: "click",
      selector: "#a",
    });
    expect(normalizeRawStep({ type: "fill", selector: "#q", value: "hi" })).toEqual({
      type: "fill",
      selector: "#q",
      value: "hi",
    });
    expect(() => normalizeRawStep({ type: "click" })).toThrow(/selector/);
    expect(() => normalizeRawStep({ type: "teleport" })).toThrow(/Unknown step/);
  });
});

describe("authorRecipe (integration, mock model)", () => {
  test(
    "records valid steps, rejects an invalid selector, and writes a readable recipe",
    { timeout: 60_000 },
    async () => {
      // Scripted model turns: valid click, invalid click (rejected), capture, finish.
      const responses = [
        toolCall("c1", "addStep", { step: { type: "click", selector: "#present" } }),
        toolCall("c2", "addStep", { step: { type: "click", selector: "#does-not-exist" } }),
        toolCall("c3", "capture", { name: "home" }),
        toolCall("c4", "finish", {}),
      ];
      let i = 0;
      const model = new MockLanguageModelV1({
        doGenerate: async () => {
          const r = responses[Math.min(i, responses.length - 1)];
          i += 1;
          return r;
        },
      });

      const logs: string[] = [];
      const { path, recipe } = await authorRecipe({
        name: "fixture",
        baseUrl: fixture,
        recipesDir: dir,
        sessionsDir: join(dir, "sessions"),
        model,
        maxModelSteps: 6,
        onLog: (m) => logs.push(m),
      });

      // Steps: goto (baseUrl), click #present, screenshot home. The bad click is NOT recorded.
      const types = recipe.steps.map((s) => s.type);
      expect(types).toEqual(["goto", "click", "screenshot"]);

      const selectors = recipe.steps
        .filter((s) => s.type === "click")
        .map((s) => (s as { selector: string }).selector);
      expect(selectors).toContain("#present");
      expect(selectors).not.toContain("#does-not-exist");

      // The written file round-trips through loadRecipe.
      const text = await readFile(path, "utf8");
      const reloaded = loadRecipe(text);
      expect(reloaded.name).toBe("fixture");
      expect(reloaded.steps).toEqual(recipe.steps);

      // The rejection was surfaced to the model (logged as a validation failure path).
      expect(i).toBeGreaterThanOrEqual(4); // model was driven through the full script
    },
  );

  test(
    "passes a custom instruction (goal) into the model prompt",
    { timeout: 60_000 },
    async () => {
      let seenPrompt = "";
      const model = new MockLanguageModelV1({
        doGenerate: async (opts) => {
          seenPrompt += JSON.stringify(opts);
          return toolCall("f", "finish", {});
        },
      });

      await authorRecipe({
        name: "fixture",
        baseUrl: fixture,
        goal: "ONLY_CAPTURE_PRICING_SCREENS_XYZ",
        recipesDir: dir,
        sessionsDir: join(dir, "sessions"),
        model,
        maxModelSteps: 2,
      });

      expect(seenPrompt).toContain("ONLY_CAPTURE_PRICING_SCREENS_XYZ");
    },
  );
});
