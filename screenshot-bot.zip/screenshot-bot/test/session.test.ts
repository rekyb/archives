import { afterEach, beforeEach, describe, expect, test } from "vitest";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { sessionPath, sessionInfo } from "../src/core/session";

let dir: string;

beforeEach(async () => {
  dir = await mkdtemp(join(tmpdir(), "sb-sess-"));
});
afterEach(async () => {
  await rm(dir, { recursive: true, force: true });
});

describe("session store", () => {
  test("sessionPath builds <dir>/<name>.json", () => {
    expect(sessionPath(dir, "acme")).toBe(join(dir, "acme.json"));
  });

  test("sessionInfo reports missing sessions", async () => {
    const info = await sessionInfo(dir, "nope");
    expect(info.exists).toBe(false);
    expect(info.mtime).toBeUndefined();
  });

  test("sessionInfo reports an existing session with an mtime", async () => {
    await writeFile(sessionPath(dir, "acme"), "{}");
    const info = await sessionInfo(dir, "acme");
    expect(info.exists).toBe(true);
    expect(info.mtime).toBeInstanceOf(Date);
  });
});
