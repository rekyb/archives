import { describe, expect, test } from "vitest";
import { extractOption, takeFlag } from "../src/cli-args";

describe("extractOption", () => {
  test("pulls --name value form and leaves positionals", () => {
    const r = extractOption(["explore", "https://x.test", "--instruction", "focus on pricing"], [
      "--instruction",
      "-i",
    ]);
    expect(r.value).toBe("focus on pricing");
    expect(r.rest).toEqual(["explore", "https://x.test"]);
  });

  test("pulls --name=value form", () => {
    const r = extractOption(["a", "--instruction=only the docs", "b"], ["--instruction", "-i"]);
    expect(r.value).toBe("only the docs");
    expect(r.rest).toEqual(["a", "b"]);
  });

  test("supports the short alias", () => {
    const r = extractOption(["-i", "hi", "site"], ["--instruction", "-i"]);
    expect(r.value).toBe("hi");
    expect(r.rest).toEqual(["site"]);
  });

  test("returns undefined value when the flag is absent", () => {
    const r = extractOption(["site", "name"], ["--instruction", "-i"]);
    expect(r.value).toBeUndefined();
    expect(r.rest).toEqual(["site", "name"]);
  });
});

describe("takeFlag", () => {
  test("detects and removes a boolean flag", () => {
    const r = takeFlag(["run", "--profile", "brilliant"], ["--profile"]);
    expect(r.present).toBe(true);
    expect(r.rest).toEqual(["run", "brilliant"]);
  });
  test("absent flag", () => {
    const r = takeFlag(["run", "brilliant"], ["--profile"]);
    expect(r.present).toBe(false);
    expect(r.rest).toEqual(["run", "brilliant"]);
  });
});
