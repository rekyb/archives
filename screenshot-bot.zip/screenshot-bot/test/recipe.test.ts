import { describe, expect, test } from "vitest";
import { loadRecipe, serializeRecipe } from "../src/core/recipe";

describe("loadRecipe", () => {
  test("parses a valid recipe and normalizes steps into tagged unions", () => {
    const recipe = loadRecipe(`
name: acme
baseUrl: https://acme.example.com
session: acme
viewport: { width: 1280, height: 720 }
steps:
  - goto: /dashboard
  - waitFor: "text=Welcome"
  - screenshot: dashboard
  - click: "role=link[name=Settings]"
  - fill: { selector: "#q", value: "hello" }
  - scroll: bottom
  - press: Enter
  - select: { selector: "#country", value: "US" }
`);

    expect(recipe.name).toBe("acme");
    expect(recipe.baseUrl).toBe("https://acme.example.com");
    expect(recipe.session).toBe("acme");
    expect(recipe.viewport).toEqual({ width: 1280, height: 720 });
    expect(recipe.steps).toEqual([
      { type: "goto", url: "/dashboard" },
      { type: "waitFor", target: "text=Welcome" },
      { type: "screenshot", name: "dashboard" },
      { type: "click", selector: "role=link[name=Settings]" },
      { type: "fill", selector: "#q", value: "hello" },
      { type: "scroll", target: "bottom" },
      { type: "press", key: "Enter" },
      { type: "select", selector: "#country", value: "US" },
    ]);
  });

  test("defaults viewport to 1440x900 when omitted", () => {
    const recipe = loadRecipe(`
name: mini
baseUrl: https://example.com
steps:
  - screenshot: home
`);
    expect(recipe.viewport).toEqual({ width: 1440, height: 900 });
    expect(recipe.session).toBeUndefined();
  });

  test("throws a clear error when baseUrl is missing", () => {
    expect(() =>
      loadRecipe(`
name: broken
steps:
  - screenshot: home
`),
    ).toThrow(/baseUrl/);
  });

  test("serializeRecipe round-trips through loadRecipe", () => {
    const yaml = `
name: acme
baseUrl: https://acme.example.com
session: acme
viewport: { width: 1280, height: 720 }
steps:
  - goto: /dashboard
  - fill: { selector: "#q", value: "hello" }
  - screenshot: dashboard
`;
    const recipe = loadRecipe(yaml);
    expect(loadRecipe(serializeRecipe(recipe))).toEqual(recipe);
  });

  test("throws a clear error naming an unknown step type", () => {
    expect(() =>
      loadRecipe(`
name: broken
baseUrl: https://example.com
steps:
  - teleport: /somewhere
`),
    ).toThrow(/teleport|unknown step/i);
  });
});
