import { afterEach, describe, expect, test, vi } from "vitest";
import { llmStatus, resolveLlmConfig } from "../src/llm/config";

// Clear all four env vars up front on each test via vi.stubEnv so the ambient
// environment (which may already have ANTHROPIC_API_KEY) can't leak in.
function clearEnv() {
  vi.stubEnv("SCREENSHOT_BOT_LLM_PROVIDER", undefined as unknown as string);
  vi.stubEnv("SCREENSHOT_BOT_LLM_MODEL", undefined as unknown as string);
  vi.stubEnv("ANTHROPIC_API_KEY", undefined as unknown as string);
  vi.stubEnv("OPENAI_API_KEY", undefined as unknown as string);
  vi.stubEnv("GEMINI_API_KEY", undefined as unknown as string);
  vi.stubEnv("GOOGLE_GENERATIVE_AI_API_KEY", undefined as unknown as string);
}

afterEach(() => {
  vi.unstubAllEnvs();
});

describe("resolveLlmConfig", () => {
  test("returns config when provider and matching key are set", () => {
    clearEnv();
    vi.stubEnv("SCREENSHOT_BOT_LLM_PROVIDER", "anthropic");
    vi.stubEnv("ANTHROPIC_API_KEY", "sk-test");

    expect(resolveLlmConfig()).toEqual({
      provider: "anthropic",
      model: "claude-opus-4-8",
    });
  });

  test("honours SCREENSHOT_BOT_LLM_MODEL override", () => {
    clearEnv();
    vi.stubEnv("SCREENSHOT_BOT_LLM_PROVIDER", "openai");
    vi.stubEnv("OPENAI_API_KEY", "sk-test");
    vi.stubEnv("SCREENSHOT_BOT_LLM_MODEL", "gpt-4o-mini");

    expect(resolveLlmConfig()).toEqual({ provider: "openai", model: "gpt-4o-mini" });
  });

  test("openai default model is gpt-4o", () => {
    clearEnv();
    vi.stubEnv("SCREENSHOT_BOT_LLM_PROVIDER", "openai");
    vi.stubEnv("OPENAI_API_KEY", "sk-test");

    expect(resolveLlmConfig()).toEqual({ provider: "openai", model: "gpt-4o" });
  });

  test("supports google/gemini with GEMINI_API_KEY and default model gemini-2.5-flash", () => {
    clearEnv();
    vi.stubEnv("SCREENSHOT_BOT_LLM_PROVIDER", "google");
    vi.stubEnv("GEMINI_API_KEY", "AI-test");

    expect(resolveLlmConfig()).toEqual({ provider: "google", model: "gemini-2.5-flash" });
  });

  test('accepts "gemini" as an alias for the google provider', () => {
    clearEnv();
    vi.stubEnv("SCREENSHOT_BOT_LLM_PROVIDER", "gemini");
    vi.stubEnv("GEMINI_API_KEY", "AI-test");

    expect(resolveLlmConfig()).toEqual({ provider: "google", model: "gemini-2.5-flash" });
  });

  test("infers google when only a Gemini key is present", () => {
    clearEnv();
    vi.stubEnv("GEMINI_API_KEY", "AI-test");

    expect(resolveLlmConfig()).toEqual({ provider: "google", model: "gemini-2.5-flash" });
  });

  test("returns null when provider is set but its key is missing", () => {
    clearEnv();
    vi.stubEnv("SCREENSHOT_BOT_LLM_PROVIDER", "anthropic");

    expect(resolveLlmConfig()).toBeNull();
  });

  test("infers provider when exactly one key is present", () => {
    clearEnv();
    vi.stubEnv("OPENAI_API_KEY", "sk-test");

    expect(resolveLlmConfig()).toEqual({ provider: "openai", model: "gpt-4o" });
  });

  test("does not infer when both keys are present and no provider chosen", () => {
    clearEnv();
    vi.stubEnv("ANTHROPIC_API_KEY", "sk-a");
    vi.stubEnv("OPENAI_API_KEY", "sk-o");

    expect(resolveLlmConfig()).toBeNull();
  });

  test("returns null when nothing is configured", () => {
    clearEnv();
    expect(resolveLlmConfig()).toBeNull();
  });
});

describe("llmStatus", () => {
  test("reports available with provider and model", () => {
    clearEnv();
    vi.stubEnv("SCREENSHOT_BOT_LLM_PROVIDER", "anthropic");
    vi.stubEnv("ANTHROPIC_API_KEY", "sk-test");

    expect(llmStatus()).toEqual({
      available: true,
      provider: "anthropic",
      model: "claude-opus-4-8",
    });
  });

  test("explains a missing key", () => {
    clearEnv();
    vi.stubEnv("SCREENSHOT_BOT_LLM_PROVIDER", "anthropic");

    const status = llmStatus();
    expect(status.available).toBe(false);
    expect(status.reason).toMatch(/ANTHROPIC_API_KEY/);
  });

  test("explains an unknown provider", () => {
    clearEnv();
    vi.stubEnv("SCREENSHOT_BOT_LLM_PROVIDER", "bogus");

    const status = llmStatus();
    expect(status.available).toBe(false);
    expect(status.reason).toMatch(/Unknown/);
  });

  test("explains nothing configured", () => {
    clearEnv();
    const status = llmStatus();
    expect(status.available).toBe(false);
    expect(status.reason).toMatch(/No LLM provider/);
  });
});
